# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.log import get_logger
from azureml._cli_common.ml_cli_error import MlCliError
from ._util import cli_context, parse_tags, get_file_content, str_to_bool, get_identity_values
from azureml.core.compute import ComputeTarget
from azureml.core.compute import AksCompute
from azureml.core.compute import AmlCompute
from azureml.core.compute import ComputeInstance
from azureml.core.compute import DsvmCompute
from azureml.core.compute import DataFactoryCompute
from azureml.core.compute import AdlaCompute
from azureml.core.compute.aks import SslConfiguration
from azureml.core.compute.aks import AksUpdateConfiguration
from azureml.exceptions import ComputeTargetException

logger = get_logger(__name__)


def computetarget_create_aks(name, agent_count, vm_size, ssl_cname, ssl_cert_pem_file, ssl_cert_key_file,
                             ssl_leaf_domain_label, ssl_overwrite_existing_domain, location, workspace_name,
                             resource_group, path, vnet_resourcegroup_name, vnet_name, subnet_name,
                             service_cidr, dns_service_ip, docker_bridge_cidr, no_wait_flag, cluster_purpose,
                             load_balancer_type, load_balancer_subnet, subscription_id, context=cli_context, verbose_local=False):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    provisioning_config = AksCompute.provisioning_configuration(agent_count, vm_size, ssl_cname, ssl_cert_pem_file,
                                                                ssl_cert_key_file, location, vnet_resourcegroup_name,
                                                                vnet_name, subnet_name, service_cidr, dns_service_ip,
                                                                docker_bridge_cidr, cluster_purpose, load_balancer_type, load_balancer_subnet)

    if ssl_leaf_domain_label:
        provisioning_config.enable_ssl(leaf_domain_label = ssl_leaf_domain_label,
                                       overwrite_existing_domain =ssl_overwrite_existing_domain)

    print('Provisioning compute resources...')
    target = ComputeTarget.create(workspace, name, provisioning_config)
    print('Resource creation submitted successfully.')

    if no_wait_flag:
        print('Resources may take 10-20 minutes to be completely provisioned.')
        print('To see if your compute target is ready to use, run:')
        print('  az ml computetarget show -n {}'.format(name))
    else:
        target.wait_for_completion(verbose_local)

    return target.serialize(), verbose_local

def computetarget_update_aks(name, workspace_name, resource_group, ssl_cname, ssl_cert_pem_file, ssl_cert_key_file,
                                    ssl_leaf_domain_label, ssl_renew_certificate, ssl_overwrite_existing_domain,
                                    ssl_disable, path, no_wait_flag, load_balancer_type, load_balancer_subnet,
                                    subscription_id, context=cli_context, verbose_local=False):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        compute_target = ComputeTarget(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no computetarget with name {} in workspace {} in '
                             'resource group {} found to update.'.format(name, workspace_name, resource_group))
        else:
            raise e

    if not isinstance(compute_target, AksCompute):
        raise MlCliError('Error, update is not supported for compute target of '
                         'type "{}"'.format(compute_target._compute_type))

    ssl_disable = str_to_bool(ssl_disable) if ssl_disable else False
    ssl_renew_certificate = str_to_bool(ssl_renew_certificate) if ssl_renew_certificate else False
    ssl_overwrite_existing_domain = str_to_bool(ssl_overwrite_existing_domain) if ssl_overwrite_existing_domain \
        else False
    if ssl_disable and ssl_renew_certificate:
        raise MlCliError('Error, --ssl-disable and --ssl-renew_certificate cannot be used together')

    ssl_configuration = None
    if ssl_disable:
        ssl_configuration = SslConfiguration(status = 'Disabled')
    elif ssl_renew_certificate:
        ssl_configuration = SslConfiguration(renew = True)
    else:
        ssl_configuration = SslConfiguration(cert=get_file_content(ssl_cert_pem_file),
                                key=get_file_content(ssl_cert_key_file),
                                cname=ssl_cname,
                                leaf_domain_label=ssl_leaf_domain_label,
                                overwrite_existing_domain=ssl_overwrite_existing_domain)

    update_config = AksUpdateConfiguration(ssl_configuration, load_balancer_type, load_balancer_subnet)
    compute_target.update(update_config)

    print('Resource update submitted successfully.')
    if no_wait_flag:
        print('Resources may take 10-20 minutes to be completely provisioned.')
        print('To see if your compute target is ready to use, run:')
        print('  az ml computetarget show -n {}'.format(name))
    else:
        compute_target.wait_for_completion(verbose_local)

    return computetarget_show(name, workspace_name, resource_group, path, subscription_id, verbose_local=verbose_local)

def computetarget_create_amlcompute(name, vm_size, vm_priority, min_nodes, max_nodes, idle_seconds_before_scaledown, vnet_resourcegroup_name,
                                    vnet_name, subnet_name, workspace_name, resource_group, path, admin_username, admin_user_password,
                                    admin_user_ssh_key, no_wait_flag, remote_login_port_public_access, subscription_id, identity, context=cli_context,
                                    verbose_local=False, tags=None, description=None, location=None, enable_node_public_ip=True):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    tags_dict = parse_tags(tags)
    identity_type, identity_id = get_identity_values(identity)

    provisioning_config = AmlCompute.provisioning_configuration(vm_size, vm_priority, min_nodes, max_nodes,
                                                                idle_seconds_before_scaledown, admin_username, admin_user_password,
                                                                admin_user_ssh_key, vnet_resourcegroup_name, vnet_name,
                                                                subnet_name, tags_dict, description, remote_login_port_public_access,
                                                                identity_type, identity_id, location, enable_node_public_ip)
    print('Provisioning compute resources...')
    target = ComputeTarget.create(workspace, name, provisioning_config)
    print('Resource creation submitted successfully.')

    if no_wait_flag:
        print('Resources may take 10-20 minutes to be completely provisioned.')
        print('To see if your compute target is ready to use, run:')
        print('  az ml computetarget show -n {}'.format(name))
    else:
        target.wait_for_completion(verbose_local)

    return target.serialize(), verbose_local


def computetarget_create_datafactory(name, location, workspace_name, resource_group, path, no_wait_flag,
                                     subscription_id, context=cli_context, verbose_local=False):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)

    provisioning_config = DataFactoryCompute.provisioning_configuration(location)

    print('Provisioning compute resources...')
    target = ComputeTarget.create(workspace, name, provisioning_config)
    print('Resource creation submitted successfully.')

    if no_wait_flag:
        print('Resources may take 10-20 minutes to be completely provisioned.')
        print('To see if your compute target is ready to use, run:')
        print('  az ml computetarget show -n {}'.format(name))
    else:
        target.wait_for_completion(verbose_local)

    return target.serialize(), verbose_local


def computetarget_delete(name, workspace_name, resource_group, path, verbose_local, subscription_id, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        compute_target = ComputeTarget(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no computetarget with name {} in workspace {} in '
                             'resource group {} found to delete.'.format(name, workspace_name, resource_group))
        else:
            raise e
    compute_target.delete()

    print('Resource deletion successfully submitted.')
    print('Resources may take a few minutes to be completely deprovisioned.')

    return compute_target.serialize(), verbose_local

def computetarget_detach(name, workspace_name, resource_group, path, verbose_local, subscription_id, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        compute_target = ComputeTarget(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no computetarget with name {} in workspace {} in '
                             'resource group {} found to detach.'.format(name, workspace_name, resource_group))
        else:
            raise e
    compute_target.detach()

    print('Resource detach successfully submitted.')
    print('Resources may take a few minutes to be completely detached.')

    return compute_target.serialize(), verbose_local

def computetarget_show(name, workspace_name, resource_group, path, subscription_id, verbose_local=False, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        compute_target = ComputeTarget(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no computetarget with name {} in workspace {} in '
                             'resource group {} found to update.'.format(name, workspace_name, resource_group))
        else:
            raise e
    return compute_target.serialize(), verbose_local


def computetarget_list(workspace_name, resource_group, path, subscription_id, verbose_local=False, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    target_list = ComputeTarget.list(workspace)
    targets = []
    for compute_target in target_list:
        targets.append(compute_target.serialize())
    return targets, verbose_local


def computetarget_get_credentials(name, workspace_name, resource_group, path, verbose_local, subscription_id, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        compute_target = ComputeTarget(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no computetarget with name {} in workspace {} in '
                             'resource group {} found to update.'.format(name, workspace_name, resource_group))
        else:
            raise e

    try:
        result = compute_target.get_credentials()
    except NotImplementedError:
        raise MlCliError('Error, get-credentials is not supported for compute target of '
                         'type "{}"'.format(compute_target._compute_type))

    return result, verbose_local

def computetarget_update_amlcompute(name, workspace_name, resource_group, path, min_nodes, max_nodes,
                                    idle_seconds_before_scaledown, subscription_id, context=cli_context, verbose_local=False):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        compute_target = ComputeTarget(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no computetarget with name {} in workspace {} in '
                             'resource group {} found to update.'.format(name, workspace_name, resource_group))
        else:
            raise e

    try:
        compute_target.update(min_nodes, max_nodes, idle_seconds_before_scaledown)
    except NotImplementedError:
        raise MlCliError('Error, update is not supported for compute target of '
                         'type "{}"'.format(compute_target._compute_type))

    print('Resource update successfully submitted.')
    print('Resources may take a few minutes to be completely updated.')

    return compute_target.serialize(), verbose_local

def computetarget_update_identity_amlcompute(name, workspace_name, resource_group, path, identity, subscription_id, context=cli_context, verbose_local=False):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    identity_type, identity_id = get_identity_values(identity)
    try:
        compute_target = ComputeTarget(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no computetarget with name {} in workspace {} in '
                             'resource group {} found to update.'.format(name, workspace_name, resource_group))
        else:
            raise e

    try:
        compute_target.add_identity(identity_type, identity_id)
    except NotImplementedError:
        raise MlCliError('Error, update identity is not supported for compute target of '
                         'type "{}"'.format(compute_target._compute_type))

    print('Resource update successfully submitted.')
    print('Resources may take a few minutes to be completely updated.')

    return compute_target.serialize(), verbose_local

def computetarget_remove_identity_amlcompute(name, workspace_name, resource_group, path, identity, subscription_id, context=cli_context, verbose_local=False):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    _ , identity_id = get_identity_values(identity)
    try:
        compute_target = ComputeTarget(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no computetarget with name {} in workspace {} in '
                             'resource group {} found to update.'.format(name, workspace_name, resource_group))
        else:
            raise e

    try:
        compute_target.remove_identity(identity_id = identity_id)
    except NotImplementedError:
        raise MlCliError('Error, removing identity is not supported for compute target of '
                         'type "{}"'.format(compute_target._compute_type))

    print('Resource update successfully submitted.')
    print('Resources may take a few minutes to be completely updated.')

    return compute_target.serialize(), verbose_local

def computetarget_identity_show_amlcompute(name, workspace_name, resource_group, path, subscription_id, context=cli_context, verbose_local=False):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        compute_target = ComputeTarget(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no computetarget with name {} in workspace {} in '
                             'resource group {} found to show.'.format(name, workspace_name, resource_group))
        else:
            raise e

    return compute_target.get()['identity'], verbose_local

def computetarget_create_computeinstance(name, vm_size, vnet_name, vnet_resourcegroup_name, subnet_name,
                                         workspace_name, resource_group, path, ssh_public_access,
                                         admin_user_ssh_public_key, no_wait_flag, subscription_id,
                                         context=cli_context, verbose_local=False, tags=None, description=None,
                                         assigned_user_object_id=None, assigned_user_tenant_id=None):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    tags_dict = parse_tags(tags)

    if isinstance(ssh_public_access, str) and ssh_public_access.lower() == "true":
        ssh_public_access = True

    provisioning_config = ComputeInstance.provisioning_configuration(
        vm_size,
        ssh_public_access,
        admin_user_ssh_public_key,
        vnet_resourcegroup_name,
        vnet_name,
        subnet_name,
        tags_dict,
        description,
        assigned_user_object_id,
        assigned_user_tenant_id)

    print('Creating compute instance...')
    target = ComputeTarget.create(workspace, name, provisioning_config)

    if no_wait_flag:        
        print('Compute instance creation submitted successfully.')
        print('Resources may take 10-20 minutes to be completely provisioned.')
        print('To see if your compute instance is ready to use, run:')
        print('  az ml computetarget show -n {}'.format(name))
    else:
        target.wait_for_completion(verbose_local)
    return target.serialize(), verbose_local

def computetarget_computeinstance_stop(name, workspace_name, resource_group, path, no_wait_flag,
                                       subscription_id, context=cli_context, verbose_local=False):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        instance = ComputeInstance(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no compute instance with name {} in workspace {} in '
                             'resource group {} found to update.'.format(name, workspace_name, resource_group))
        else:
            raise

    if no_wait_flag:
        instance.stop(wait_for_completion=False, show_output=False)
        print('Compute instance may take few minutes to stop.')
        print('To see the current status of compute instance, run:')
        print('  az ml computetarget show -n {}'.format(name))
    else:
        instance.stop(wait_for_completion=True, show_output=verbose_local)
    return instance.serialize(), verbose_local

def computetarget_computeinstance_start(name, workspace_name, resource_group, path, no_wait_flag,
                                        subscription_id, context=cli_context, verbose_local=False):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        instance = ComputeInstance(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no compute instance with name {} in workspace {} in '
                             'resource group {} found to update.'.format(name, workspace_name, resource_group))
        else:
            raise

    if no_wait_flag:
        instance.start(wait_for_completion=False, show_output=False)
        print('Compute instance may take few minutes to start.')
        print('To see the current status of compute instance, run:')
        print('  az ml computetarget show -n {}'.format(name))
    else:
        instance.start(wait_for_completion=True, show_output=verbose_local)
    return instance.serialize(), verbose_local

def computetarget_computeinstance_restart(name, workspace_name, resource_group, path, no_wait_flag,
                                          subscription_id, context=cli_context, verbose_local=False):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        instance = ComputeInstance(workspace, name)
    except ComputeTargetException as e:
        if 'ComputeTargetNotFound' in e.message:
            raise MlCliError('Error, no compute instance with name {} in workspace {} in '
                             'resource group {} found to update.'.format(name, workspace_name, resource_group))
        else:
            raise

    if no_wait_flag:
        instance.restart(wait_for_completion=False, show_output=False)
        print('Compute instance may take few minutes to restart.')
        print('To see the current status of compute instance, run:')
        print('  az ml computetarget show -n {}'.format(name))
    else:
        instance.restart(wait_for_completion=True, show_output=verbose_local)
    return instance.serialize(), verbose_local