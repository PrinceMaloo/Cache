# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.cli.core.commands import client_factory
from azureml._cli_common.ml_cli_error import MlCliError
from ._mlc.machine_learning_compute_management_client import MachineLearningComputeManagementClient
from ._mlc.models.operationalization_cluster import OperationalizationCluster
from ._mlc.models.mlc_enums import ClusterType
from ._mlc.models.acs_cluster_properties import AcsClusterProperties
from ._mlc.models.kubernetes_cluster_properties import KubernetesClusterProperties
from ._mlc.models.service_principal_properties import ServicePrincipalProperties
from ._mlc.models.error_response_wrapper import ErrorResponseWrapperException
from ._mlc.models.global_service_configuration import GlobalServiceConfiguration
from ._mlc.models.ssl_configuration import SslConfiguration
from ._mlc.models.storage_account_properties import StorageAccountProperties
from ._mlc.models.container_registry_properties import ContainerRegistryProperties


def __get_client():
    from azure.cli.core import get_default_cli
    return client_factory.get_mgmt_service_client(get_default_cli(),
                                                  MachineLearningComputeManagementClient).operationalization_clusters


def get_compute_resource(resource_group, cluster_name):
    client = __get_client()
    cluster = client.get(resource_group, cluster_name)
    if cluster.provisioning_errors:
        try:
            error_details = cluster.provisioning_errors[0].error.details
            for detail in error_details:
                if detail.code != 'Ok' and 'exceeding quota limits' in detail.message:
                    detail.message = 'Resource quota limit exceeded.'
                    break
        except:
            cluster.provisioning_errors = None
    return serialize_operationalization_cluster(cluster)


def get_current_compute_resource(context):
    context.validate_active_and_compute_subscriptions()
    if (context.current_compute_resource_group is None or
        context.current_compute_name is None):
        raise MlCliError('Resource group and compute name must be provided if current environment is unset.')

    try:
        return get_compute_resource(context.current_compute_resource_group,
                                    context.current_compute_name)
    except ErrorResponseWrapperException:
        context.unset_current_compute_and_warn_user()
        raise


def create_compute_resource(resource_group, cluster_name, cluster_type, sp_id, sp_pw,
                            location, agent_count, agent_vm_size, cert_str, key_str, ssl_enabled,
                            storage_arm_id, acr_arm_id, cert_cname, master_count):
    client = __get_client()
    orchestrator_type = 'Kubernetes'
    container_service = AcsClusterProperties(
        orchestrator_type=orchestrator_type,
        master_count=master_count
    )

    if agent_count:
        container_service.agent_count=agent_count

    if agent_vm_size:
        container_service.agent_vm_size=agent_vm_size

    if sp_id and sp_pw:
        orchestrator_properties = KubernetesClusterProperties()
        orchestrator_properties.service_principal = ServicePrincipalProperties(client_id=sp_id, secret=sp_pw)
        container_service.orchestrator_properties = orchestrator_properties

    oc = OperationalizationCluster(
        location=location,
        cluster_type=cluster_type,
        container_service=container_service,
        global_service_configuration=GlobalServiceConfiguration(
            ssl=SslConfiguration(
                status=ssl_enabled,
                cert=cert_str,
                key=key_str,
                cname=cert_cname,
            )
        ),
        storage_account=StorageAccountProperties(
            resource_id=storage_arm_id
        ),
        container_registry=ContainerRegistryProperties(
            resource_id=acr_arm_id
        )
    )
    if cluster_type == ClusterType.local:
        oc.container_service = None
    return client.create_or_update(resource_group, cluster_name, oc, raw=True).response


def update_compute_resource(resource_group, env_name, agent_count, ssl_enabled, cert_str, key_str, cert_cname):
    client = __get_client()
    cluster = client.get(resource_group, env_name)

    if cluster.cluster_type != 'ACS':
        raise MlCliError('Error, unable to update a non-ACS environment.')

    if agent_count:
        cluster.container_service.agent_count = agent_count

    if ssl_enabled:
        if ssl_enabled == 'Enabled':
            ssl = SslConfiguration(
                status=ssl_enabled,
                cert=cert_str,
                key=key_str,
                cname=cert_cname,
            )
        else:
            ssl = SslConfiguration(
                status=ssl_enabled
            )
        cluster.global_service_configuration.ssl = ssl

    return client.create_or_update(resource_group, env_name, cluster, raw=True).response


def delete_compute_resource(resource_group, cluster_name):
    client = __get_client()
    return client.delete(resource_group, cluster_name, delete_all=True, raw=True).response


def get_compute_resource_keys(resource_group, cluster_name):
    client = __get_client()
    return client.list_keys(resource_group, cluster_name)


def serialize_operationalization_cluster(operationalization_cluster):
    serialized_cluster = operationalization_cluster.as_dict(keep_readonly=True)
    cluster_details = operationalization_cluster.id.split('/')
    serialized_cluster['subscription'] = cluster_details[2]
    serialized_cluster['resource_group'] = cluster_details[4]
    serialized_cluster['current_execution_mode'] = 'local' if operationalization_cluster.cluster_type.lower() == ClusterType.local.value.lower() else 'cluster'

    return serialized_cluster


def prompt_for_resource_reuse(storage_arm_id, acr_arm_id, yes, context):
    if yes:
        answer = 'yes'
    else:
        answer = context.get_input('Reuse storage and ACR (Y/n)? ').lower()
    if answer != 'n' and answer != 'no':
        storage_arm_id = context.current_env['storage_account']['resource_id']
        acr_arm_id = context.current_env['container_registry']['resource_id']
        print('Continuing setup with current storage and acr')
    return storage_arm_id, acr_arm_id
