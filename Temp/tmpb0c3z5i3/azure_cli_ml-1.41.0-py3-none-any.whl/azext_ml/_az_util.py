# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""
Utilities to interact with the Azure CLI (az).
"""

import errno
import os
import platform
import re
import stat
import requests
import yaml
from azure.cli.core._profile import Profile
from azure.cli.core.commands import client_factory
from azure.cli.core.util import CLIError
from azure.mgmt.resource.resources import ResourceManagementClient
from azure.mgmt.resource.resources.models import ResourceGroup
from knack.log import get_logger
from azureml._cli_common.ml_cli_error import MlCliError
from ._util import cli_context

logger = get_logger(__name__)

# add constructor for unicode to safe loader, as we were previously
# using dump instead of safe_dump
yaml.SafeLoader.add_constructor("tag:yaml.org,2002:python/unicode",
                                lambda loader, node: node.value)


def validate_env_name(name):
    """
    Validate the given name against Azure storage naming rules
    :param name: The name to validate
    :return: None, if valid. Throws an exception otherwise.
    """
    if not name or len(name) > 20:
        raise MlCliError('Invalid environment name. Name must be between 1 and 20 characters in length.')

    if not bool(re.match('^[a-z0-9]+$', name)):
        raise MlCliError('Invalid environment name. Name must only contain lowercase alphanumeric characters.')


def az_login(app_id=None, client_secret=None, tenant=None, yes=False):
    """Log in to Azure if not already logged in
    :return None
    """
    profile = Profile()
    if app_id and client_secret and tenant:
        profile.find_subscriptions_on_login(False, app_id, client_secret, True, tenant)
        return

    # interactive login
    try:
        profile.get_subscription()
    except CLIError as exc:
        # thrown when not logged in
        if "'az login'" in str(exc):
            if yes:
                raise MlCliError('Unable to run with -y flag until you are logged in. Attempt to get subscription '
                                 'failed: {}'.format(exc))
            profile.find_subscriptions_on_login(True, None, None, None, None)
        elif "'az account set'" in str(exc):
            # TODO - figure out what to do here..
            raise
        else:
            raise


def az_check_subscription(yes=False, context=cli_context):
    """
    Check whether the user wants to use the current default subscription
    Assumes user is logged in to az.
    """
    profile = Profile()
    current_subscription = profile.get_subscription()['name']
    if yes:
        return current_subscription
    print('Subscription set to {}'.format(current_subscription))
    answer = context.get_input('Continue with this subscription (Y/n)? ')
    answer = answer.rstrip().lower()
    if answer == 'n' or answer == 'no':
        print("Available subscriptions:\n  {}".format('\n  '.join(
            [sub['name'] for sub in profile.load_cached_subscriptions()])))
        new_subscription = context.get_input('Enter subscription name: ').rstrip()
        az_set_active_subscription(new_subscription)
    return profile.get_subscription()['name']


def az_get_active_subscription_id():
    return Profile().get_subscription()['id']


def az_set_active_subscription(subscription):
    profile = Profile()
    profile.set_active_subscription(
        profile.get_subscription(subscription)['name'])
    print('Active subscription updated to {}'.format(
        profile.get_subscription()['name']))


def az_create_resource_group(context, root_name, append='rg', location=None):
    """Create a resource group using root_name as a prefix"""
    from azure.cli.core import get_default_cli

    rg_name = root_name + append
    rg_client = client_factory.get_mgmt_service_client(get_default_cli(),
        ResourceManagementClient).resource_groups

    if rg_client.check_existence(rg_name):
        print('Resource group {} already exists, skipping creation.'.format(rg_name))
    else:
        print("Creating resource group {}".format(rg_name))
        rg_client.create_or_update(
            rg_name,
            ResourceGroup(location=location or context.aml_env_default_location)
        )

    return rg_name


def az_register_provider(namespace):
    """ Registers a given resource provider with Azure."""
    from azure.cli.core import get_default_cli
    client = client_factory.get_mgmt_service_client(get_default_cli(), ResourceManagementClient).providers
    client.register(namespace)


def az_get_provider(namespace):
    """ Registers a given resource provider with Azure."""
    from azure.cli.core import get_default_cli
    client = client_factory.get_mgmt_service_client(get_default_cli(), ResourceManagementClient).providers
    return client.get(namespace)


def az_install_kubectl(context):
    """Downloads kubectl from kubernetes.io and adds it to the system path."""
    full_install_path = kubectl_path(context)
    _makedirs(os.path.dirname(full_install_path))
    os.environ['PATH'] += os.pathsep + os.path.dirname(full_install_path)
    _k8s_install_cli(install_location=full_install_path)
    return True


def kubectl_path(context):
    executable = 'kubectl' if context.os_is_unix() else 'kubectl.exe'
    return os.path.join(os.path.expanduser('~'), 'bin', executable)


def _makedirs(path):
    try:
        os.makedirs(path)
    except OSError as exc:
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else:
            raise


def _k8s_install_cli(client_version='latest', install_location=None):
    """
    Downloads the kubectl command line from Kubernetes
    """

    if client_version == 'latest':
        resp = requests.get(
            'https://storage.googleapis.com/kubernetes-release/release/stable.txt')
        resp.raise_for_status()
        client_version = resp.content.decode().strip()

    system = platform.system()
    base_url = 'https://storage.googleapis.com/kubernetes-release/release/{}/bin/{}/amd64/{}'
    if system == 'Windows':
        file_url = base_url.format(client_version, 'windows', 'kubectl.exe')
    elif system == 'Linux':
        # TODO: Support ARM CPU here
        file_url = base_url.format(client_version, 'linux', 'kubectl')
    elif system == 'Darwin':
        file_url = base_url.format(client_version, 'darwin', 'kubectl')
    else:

        raise MlCliError('Proxy server ({}) does not exist on the cluster.'.format(system))

    logger.warning('Downloading client to %s from %s', install_location, file_url)
    try:
        with open(install_location, 'wb') as kubectl:
            resp = requests.get(file_url)
            resp.raise_for_status()
            kubectl.write(resp.content)
            os.chmod(install_location,
                     os.stat(
                         install_location).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        logger.warning('Ensure {} is on the path to avoid seeing this message in the future.'.format(install_location))
    except (requests.exceptions.HTTPError, requests.exceptions.ConnectionError) as err:
        raise MlCliError('Connection error while attempting to download client', content=err)
