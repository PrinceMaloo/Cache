# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from __future__ import print_function
import os
import subprocess
import traceback
from ._az_util import az_install_kubectl
from ._az_util import kubectl_path
from ._util import print_util


class K8sConstants(object):
    DEFAULT_STORAGE_CONNECTION_STRING = 0
    ACR_SECRET = 1
    KUBE_CONFIG_PATH = os.path.join(os.path.expanduser('~'), '.kube', 'config')
    AML_FE_BLOB_LOCATION = "https://azuremlintfe.blob.core.windows.net/deploymentspecs/azureml-fe-dep-0-latest.yaml"
    WEBSERVICE_LABEL = "webservicename"


def _check_kubectl_in_path(context):
    try:
        with open(os.devnull, 'w') as devnull:
            context.check_output('kubectl', stderr=devnull)
        return True
    except (subprocess.CalledProcessError, OSError):
        return False


def _install_kubectl(context, verb):
    try:
        az_install_kubectl(context)
        return True
    except PermissionError:
        print("You do not have permissions to install kubectl, please contact your system administrator")
        print_util(traceback.format_exc(), verb)
        return False
    except:
        print("Failed to installed kubectl")
        print_util(traceback.format_exc(), verb)
        return False


def check_for_kubectl(context, verb=False):
    """Checks whether kubectl is present on the system path or in the default installation location"""
    if _check_kubectl_in_path(context):
        print_util("Kubectl found in PATH", verb)
        return True
    elif os.path.exists(kubectl_path(context)):
        # ensure kubectl installation is in path
        print_util("Kubectl exists in default location, adding it to PATH", verb)
        os.environ['PATH'] += os.pathsep + os.path.dirname(kubectl_path(context))
        return True
    else:
        print_util("Kubectl is neither in PATH nor in default location", verb)
        auto_install = context.get_input(
            'kubectl is not installed. One click install? (Y/n): ').lower().strip()
        if 'n' not in auto_install and 'no' not in auto_install:
            return _install_kubectl(context, verb)
        else:
            print('To install Kubectl run the following commands and then re-run az ml env setup')
            print('curl -LO https://storage.googleapis.com/kubernetes-release/release/' +
                  '$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)' +
                  '/bin/linux/amd64/kubectl')
            print('chmod +x ./kubectl')
            print('sudo mv ./kubectl ~/bin')
            return False
