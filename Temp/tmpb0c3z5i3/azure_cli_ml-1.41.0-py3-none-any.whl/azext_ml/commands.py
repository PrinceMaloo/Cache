# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


from azureml._cli_common.transformers import transform_model_delete
from azureml._cli_common.transformers import table_transform_mlc_resource_list
from azureml._cli_common.transformers import transform_mlc_delete
from azureml._cli_common.transformers import transform_mlc_get_creds
from azureml._cli_common.transformers import table_transform_mlc_get_creds
from azureml._cli_common.transformers import table_transform_mlc_resource
from azureml._cli_common.transformers import table_transform_mlc_delete
from azureml._cli_common.transformers import transform_mlc_resource
from azureml._cli_common.transformers import transform_amlcompute_identity_resource
from azureml._cli_common.transformers import table_transform_model_delete
from azureml._cli_common.transformers import transform_service_run
from azureml._cli_common.transformers import table_transform_service_run
from azureml._cli_common.transformers import transform_service_delete
from azureml._cli_common.transformers import table_transform_service_delete
from azureml._cli_common.transformers import transform_service_keys
from azureml._cli_common.transformers import table_transform_service_keys
from azureml._cli_common.transformers import transform_model_show
from azureml._cli_common.transformers import table_transform_model_show
from azureml._cli_common.transformers import transform_model_list
from azureml._cli_common.transformers import table_transform_model_list
from azureml._cli_common.transformers import transform_model_delete
from azureml._cli_common.transformers import table_transform_model_delete
from azureml._cli_common.transformers import transform_package
from azureml._cli_common.transformers import table_transform_package
from azureml._cli_common.transformers import transform_model_profile
from azureml._cli_common.transformers import table_transform_model_profile
from azureml._cli_common.transformers import transform_service_show
from azureml._cli_common.transformers import table_transform_endpoint_show
from azureml._cli_common.transformers import transform_endpoint_list
from azureml._cli_common.transformers import table_transform_endpoint_list
from azureml._cli_common.transformers import transform_endpoint_show
from azureml._cli_common.transformers import table_transform_service_show
from azureml._cli_common.transformers import transform_service_list
from azureml._cli_common.transformers import table_transform_service_list
from azureml._cli_common.transformers import transform_mlc_resource_list
from azureml._cli_common.transformers import transform_access_tokens
from azureml._cli_common.transformers import table_transform_access_tokens
from azureml._cli_common.transformers import transform_computeinstance_resource
from azureml._cli_common.transformers import table_transform_computeinstance_resource
from azureml._cli_common.cli_exception_handler import _handle_exceptions


# Every command has several parts:
#
# 1. Commands [Add your command to ALL_COMMANDS so that it gets added. Optional arguments for
# registration (such as table_transformer) that must be provided to "cli_command" should be
# included as part of the dictionary in ALL_COMMANDS. Otherwise, add an empty dictionary.]
#
# 2. Command Information [Create a new key for your command in command_details.json.
# This will contain its name, the command itself, the command function/pointer, and arguments.]
#
# 3. Arguments [Should be added as part of the command_details.json file. See other commands for examples.]
#
# 4. Module [Functions called by the commands, make sure to specify their name when
# creating the command.]
#
# 5. Help [Warning: Help is not in this file! Make sure to update _help.py,
# which is under the same directory, with the new commands.]


ALL_COMMANDS = {
    "ml computetarget create aks": {"exception_handler": _handle_exceptions, "transform": transform_mlc_resource, "table_transformer": table_transform_mlc_resource},
    "ml computetarget create amlcompute": {"exception_handler": _handle_exceptions, "transform": transform_mlc_resource, "table_transformer": table_transform_mlc_resource},
    "ml computetarget create datafactory": {"exception_handler": _handle_exceptions, "transform": transform_mlc_resource, "table_transformer": table_transform_mlc_resource},
    "ml computetarget list": {"exception_handler": _handle_exceptions, "transform": transform_mlc_resource_list, "table_transformer": table_transform_mlc_resource_list},
    "ml computetarget show": {"exception_handler": _handle_exceptions, "transform": transform_mlc_resource, "table_transformer": table_transform_mlc_resource},
    "ml computetarget delete": {'exception_handler': _handle_exceptions, "transform": transform_mlc_delete, "table_transformer": table_transform_mlc_delete},
    "ml computetarget detach": {'exception_handler': _handle_exceptions, "transform": transform_mlc_delete, "table_transformer": transform_mlc_delete},
    "ml computetarget get-credentials": {"exception_handler": _handle_exceptions, "transform": transform_mlc_get_creds, "table_transformer": table_transform_mlc_get_creds},
    "ml computetarget update amlcompute": {"exception_handler": _handle_exceptions, "transform": transform_mlc_resource, "table_transformer": table_transform_mlc_resource},
    "ml computetarget update aks": {"exception_handler": _handle_exceptions, "transform": transform_mlc_resource, "table_transformer": table_transform_mlc_resource},
    "ml computetarget amlcompute identity assign": {"exception_handler": _handle_exceptions, "transform": transform_mlc_resource, "table_transformer": table_transform_mlc_resource},
    "ml computetarget amlcompute identity remove": {"exception_handler": _handle_exceptions, "transform": transform_mlc_resource, "table_transformer": table_transform_mlc_resource},
    "ml computetarget amlcompute identity show": {"exception_handler": _handle_exceptions, "transform": transform_amlcompute_identity_resource, "table_transformer": table_transform_mlc_resource},    
    "ml computetarget create computeinstance": {"exception_handler": _handle_exceptions, "transform": transform_mlc_resource, "table_transformer": table_transform_mlc_resource},
    "ml computetarget computeinstance stop": {"exception_handler": _handle_exceptions, "transform": transform_computeinstance_resource, "table_transformer": table_transform_computeinstance_resource},
    "ml computetarget computeinstance start": {"exception_handler": _handle_exceptions, "transform": transform_computeinstance_resource, "table_transformer": table_transform_computeinstance_resource},
    "ml computetarget computeinstance restart": {"exception_handler": _handle_exceptions, "transform": transform_computeinstance_resource, "table_transformer": table_transform_computeinstance_resource},
    

    # Endpoints aks
    "ml endpoint realtime list": {"exception_handler": _handle_exceptions, "transform": transform_endpoint_list, "table_transformer": table_transform_endpoint_list},
    "ml endpoint realtime show": {"exception_handler": _handle_exceptions, "transform": transform_endpoint_show, "table_transformer": table_transform_endpoint_show},
    "ml endpoint realtime delete": {"exception_handler": _handle_exceptions, "transform": transform_service_delete, "table_transformer": table_transform_service_delete},
    "ml endpoint realtime run": {"exception_handler": _handle_exceptions, "transform": transform_service_run, "table_transformer": table_transform_service_run},
    "ml endpoint realtime regen-key": {"exception_handler": _handle_exceptions, "transform": transform_service_keys, "table_transformer": table_transform_service_keys},
    "ml endpoint realtime get-keys": {"exception_handler": _handle_exceptions, "transform": transform_service_keys, "table_transformer": table_transform_service_keys},
    "ml endpoint realtime get-access-token": {"exception_handler": _handle_exceptions, "transform": transform_access_tokens, "table_transformer": table_transform_access_tokens},
    "ml endpoint realtime get-logs": {"exception_handler": _handle_exceptions},  # No transformations for log retrieval
    "ml endpoint realtime update": {"exception_handler": _handle_exceptions, "transform": transform_endpoint_show, "table_transformer": table_transform_endpoint_show},
    "ml endpoint realtime create-version": {"exception_handler": _handle_exceptions, "transform": transform_endpoint_show, "table_transformer": table_transform_endpoint_show},
    "ml endpoint realtime update-version": {"exception_handler": _handle_exceptions, "transform": transform_endpoint_show, "table_transformer": table_transform_endpoint_show},
    "ml endpoint realtime delete-version": {"exception_handler": _handle_exceptions, "transform": transform_endpoint_show, "table_transformer": table_transform_endpoint_show},

    # Services
    "ml service list": {"exception_handler": _handle_exceptions, "transform": transform_service_list, "table_transformer": table_transform_service_list},
    "ml service show": {"exception_handler": _handle_exceptions, "transform": transform_service_show, "table_transformer": table_transform_service_show},
    "ml service delete": {"exception_handler": _handle_exceptions, "transform": transform_service_delete, "table_transformer": table_transform_service_delete},
    "ml service run": {"exception_handler": _handle_exceptions, "transform": transform_service_run, "table_transformer": table_transform_service_run},
    "ml service regen-key": {"exception_handler": _handle_exceptions, "transform": transform_service_keys, "table_transformer": table_transform_service_keys},
    "ml service get-keys": {"exception_handler": _handle_exceptions, "transform": transform_service_keys, "table_transformer": table_transform_service_keys},
    "ml service get-access-token": {"exception_handler": _handle_exceptions, "transform": transform_access_tokens, "table_transformer": table_transform_access_tokens},
    "ml service get-logs": {"exception_handler": _handle_exceptions},  # No transformations for log retrieval
    "ml service update": {"exception_handler": _handle_exceptions, "transform": transform_service_show, "table_transformer": table_transform_service_show},

    # Models
    # verbs reister, show, update share the same output transformers
    "ml model register": {"exception_handler": _handle_exceptions, "transform": transform_model_show, "table_transformer": table_transform_model_show},
    "ml model show": {"exception_handler": _handle_exceptions, "transform": transform_model_show, "table_transformer": table_transform_model_show},
    "ml model list": {"exception_handler": _handle_exceptions, "transform": transform_model_list, "table_transformer": table_transform_model_list},
    "ml model delete": {"exception_handler": _handle_exceptions, "transform": transform_model_delete, "table_transformer": table_transform_model_delete},
    "ml model update": {"exception_handler": _handle_exceptions, "transform": transform_model_show, "table_transformer": table_transform_model_show},
    # TODO: for now use transform_model_show, but we should output model + download path
    "ml model download": {"exception_handler": _handle_exceptions, "transform": transform_model_show, "table_transformer": table_transform_model_show},
    # verb deploy uses the output transformer for "service show" for now
    "ml model deploy": {"exception_handler": _handle_exceptions, "transform": transform_service_show, "table_transformer": table_transform_service_show},
    "ml model profile": {"exception_handler": _handle_exceptions, "transform": transform_model_profile, "table_transformer": table_transform_model_profile},
    "ml model package": {"exception_handler": _handle_exceptions, "transform": transform_package, "table_transformer": table_transform_package}
}
