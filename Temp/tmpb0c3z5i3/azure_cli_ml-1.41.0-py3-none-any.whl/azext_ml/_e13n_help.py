# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

# pylint: disable=line-too-long, too-many-lines
from knack.help_files import helps

# Note: Documentation is this file will override any other documentation for the
# the same commands for az CLI. For example, this file overrides the documentation
# of commands written in azureml._cli sub-packages.

helps['ml'] = """
    type: group
    short-summary: Access Machine Learning commands.
"""

helps['ml computetarget'] = """
    type: group
    short-summary: Access compute context related commands.
"""

helps['ml computetarget list'] = """
    type: command
    short-summary: List all the compute targets attached to a workspace.
"""

helps['ml computetarget show'] = """
    type: command
    short-summary: Show details of a specific compute target.
"""

helps['ml computetarget detach'] = """
    type: command
    short-summary: Detach a compute target (aks or remote) from a workspace.
"""

helps['ml computetarget attach'] = """
    type: group
    short-summary: Attach a compute target (aks or remote).
"""

helps['ml computetarget create'] = """
    type: group
    short-summary: Create a compute target (aks or amlcompute or computeinstance).
"""

helps['ml computetarget delete'] = """
    type: command
    short-summary: Delete a compute target (aks or amlcompute or computeinstance).
"""

helps['ml computetarget get-credentials'] = """
    type: command
    short-summary: Get credentials for a compute target (aks or remote).
"""

helps['ml computetarget attach remote'] = """
    type: command
    short-summary: Attach a remote machine as a compute target to the workspace .
"""

helps['ml computetarget create aks'] = """
    type: command
    short-summary: Create an AKS compute target.
"""

helps['ml computetarget create amlcompute'] = """
    type: command
    short-summary: Create an AzureML compute target.
"""

helps['ml computetarget create datafactory'] = """
    type: command
    short-summary: Create a data factory compute target.
"""

helps['ml computetarget update'] = """
    type: group
    short-summary: Update a compute target (aks or amlcompute).
"""

helps['ml computetarget update amlcompute'] = """
    type: command
    short-summary: Update an AzureML compute target.
"""

helps['ml computetarget update aks'] = """
    type: command
    short-summary: Update an AKS compute target.
"""

helps['ml computetarget amlcompute'] = """
    type: group
    short-summary: AzureML compute commands.
"""

helps['ml computetarget amlcompute identity'] = """
    type: group
    short-summary: AzureML compute target identity commands.
"""

helps['ml computetarget amlcompute identity assign'] = """
    type: command
    short-summary: Assign identity to an AzureML compute target.
"""

helps['ml computetarget amlcompute identity remove'] = """
    type: command
    short-summary: Remove identity from an AzureML compute target.
"""

helps['ml computetarget amlcompute identity show'] = """
    type: command
    short-summary: Display identities of an AzureML compute target.
"""

helps['ml computetarget create computeinstance'] = """
    type: command
    short-summary: Create an AzureML compute instance target.
"""

helps['ml computetarget computeinstance'] = """
    type: group
    short-summary: AzureML compute instance commands.
"""

helps['ml computetarget computeinstance stop'] = """
    type: command
    short-summary: Stop a compute instance.
"""

helps['ml computetarget computeinstance start'] = """
    type: command
    short-summary: Start a compute instance.
"""

helps['ml computetarget computeinstance restart'] = """
    type: command
    short-summary: Restart a compute instance.
"""