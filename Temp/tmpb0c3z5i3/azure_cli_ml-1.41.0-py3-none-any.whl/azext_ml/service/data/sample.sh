export AML_STORAGE_ACCT_NAME=!!FILL_IN!!
export AML_STORAGE_ACCT_KEY=!!FILL_IN!!
export AML_ACR_HOME=amlacrtest-exp.azurecr.io
export AML_ACR_USER=amlacrtest
export AML_ACR_PW=sfk=tJX5m0S=pWs=R92Zwe1a0GwVq8es
export AML_ACS_MASTER=rbacsmaster.southcentralus.cloudapp.azure.com
export AML_ACS_AGENT=rbacsagent.southcentralus.cloudapp.azure.com
