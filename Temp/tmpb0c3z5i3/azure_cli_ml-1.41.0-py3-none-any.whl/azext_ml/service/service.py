# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from __future__ import print_function

import copy
import json
import logging
from .._ml_cli_error import MlCliError
from .._util import cli_context, collect_input_models, create_deploy_config, create_inference_config, \
    file_stream_to_object, str_to_bool, try_get_local_service
from azureml.core.image import Image
from azureml.core.image import ContainerImage
from azureml.core.model import Model
from azureml.core.webservice import AciWebservice, AksEndpoint, AksWebservice, LocalWebservice, Webservice
from azureml.exceptions import WebserviceException
from azureml._model_management._constants import AKS_ENDPOINT_CREATE_VERSION, AKS_ENDPOINT_DELETE_VERSION, \
    AKS_ENDPOINT_TYPE, AKS_ENDPOINT_UPDATE_VERSION, CLI_METADATA_FILE_RG_KEY, CLI_METADATA_FILE_WORKSPACE_KEY, \
    COMPUTE_TYPE_KEY, IMAGE_METADATA_FILE_ID_KEY

module_logger = logging.getLogger(__name__)


def endpoint_update(endpoint_name, add_tags, remove_tags, add_properties, description, path, auth_enabled,
                    token_auth_enabled, enable_app_insights, workspace_name, resource_group, subscription_id,
                    no_wait_flag, verbose_local, context=cli_context):
    return endpoint_service_update(service_name=endpoint_name, add_tags=add_tags, remove_tags=remove_tags,
                                   add_properties=add_properties, description=description, path=path,
                                   workspace_name=workspace_name, resource_group=resource_group,
                                   no_wait_flag=no_wait_flag, verbose_local=verbose_local, auth_enabled=auth_enabled,
                                   token_auth_enabled=token_auth_enabled, enable_app_insights=enable_app_insights,
                                   context=context, expected_webservice_type=AKS_ENDPOINT_TYPE.lower(),
                                   subscription_id=subscription_id)


def endpoint_version_delete(endpoint_name, version_name, path, workspace_name, resource_group, subscription_id,
                            no_wait_flag, verbose_local, context=cli_context):

    return endpoint_service_update(service_name=endpoint_name, path=path, workspace_name=workspace_name,
                                   resource_group=resource_group, subscription_id=subscription_id,
                                   no_wait_flag=no_wait_flag, verbose_local=verbose_local,
                                   context=context, version_name=version_name,
                                   version_operation_type=AKS_ENDPOINT_DELETE_VERSION.lower(),
                                   expected_webservice_type=AKS_ENDPOINT_TYPE.lower())


def endpoint_version_create(endpoint_name, add_tags, add_properties, description, deploy_config_file, path, models,
                            model_metadata_files, inference_config_file, workspace_name, resource_group, no_wait_flag,
                            verbose_local, entry_script, conda_file, source_directory, cpu_cores,
                            memory_gb, autoscale_enabled, autoscale_min_replicas,
                            autoscale_max_replicas, autoscale_refresh_seconds, autoscale_target_utilization,
                            collect_model_data, scoring_timeout_ms, subscription_id, replica_max_concurrent_requests,
                            max_request_wait_time, num_replicas, gpu_cores, period_seconds,initial_delay_seconds,
                            timeout_seconds, success_threshold, failure_threshold, version_name, traffic_percentile,
                            is_default, is_control_version_type, environment_name, environment_version,
                            environment_directory, cpu_cores_limit, memory_gb_limit, context=cli_context):
    return endpoint_service_update(endpoint_name, add_tags, None, add_properties, description, deploy_config_file,
                                   path, models, model_metadata_files, inference_config_file, workspace_name,
                                   resource_group, no_wait_flag, verbose_local, entry_script, None, conda_file,
                                   None, source_directory, None, None, None, None, cpu_cores,
                                   memory_gb, None, None, None, None,
                                   None, None, None, None, None, autoscale_enabled, autoscale_min_replicas,
                                   autoscale_max_replicas, autoscale_refresh_seconds, autoscale_target_utilization,
                                   collect_model_data, scoring_timeout_ms, replica_max_concurrent_requests,
                                   max_request_wait_time, num_replicas, None, None, gpu_cores, period_seconds,
                                   initial_delay_seconds, timeout_seconds, success_threshold, failure_threshold, None,
                                   environment_name, environment_version, environment_directory, context, version_name,
                                   traffic_percentile, is_default, is_control_version_type,
                                   AKS_ENDPOINT_CREATE_VERSION.lower(), AKS_ENDPOINT_TYPE.lower(), subscription_id,
                                   cpu_cores_limit=cpu_cores_limit, memory_gb_limit=memory_gb_limit)


def endpoint_version_update(endpoint_name, add_tags, add_properties, description, deploy_config_file, path, models,
                            model_metadata_files, inference_config_file, workspace_name, resource_group, no_wait_flag,
                            verbose_local, entry_script, conda_file, source_directory, cpu_cores,
                            memory_gb, autoscale_enabled, autoscale_min_replicas, autoscale_max_replicas, autoscale_refresh_seconds,
                            autoscale_target_utilization, collect_model_data, scoring_timeout_ms, subscription_id,
                            replica_max_concurrent_requests, max_request_wait_time, num_replicas, gpu_cores, period_seconds,
                            initial_delay_seconds, timeout_seconds, success_threshold, failure_threshold, version_name,
                            traffic_percentile, is_default, is_control_version_type, environment_name, environment_version,
                            environment_directory, cpu_cores_limit, memory_gb_limit, context=cli_context):
    return endpoint_service_update(endpoint_name, add_tags, None, add_properties, description, deploy_config_file, path,
                                   models, model_metadata_files, inference_config_file, workspace_name, resource_group,
                                   no_wait_flag, verbose_local, entry_script, None, conda_file, None, source_directory,
                                   None, None, None, None, cpu_cores, memory_gb,
                                    None, None, None, None, None, None,
                                   None, None, None, autoscale_enabled, autoscale_min_replicas, autoscale_max_replicas,
                                   autoscale_refresh_seconds, autoscale_target_utilization, collect_model_data,
                                   scoring_timeout_ms, replica_max_concurrent_requests, max_request_wait_time,
                                   num_replicas, None, None, gpu_cores, period_seconds, initial_delay_seconds,
                                   timeout_seconds, success_threshold, failure_threshold, None, environment_name,
                                   environment_version, environment_directory, context, version_name, traffic_percentile,
                                   is_default, is_control_version_type, AKS_ENDPOINT_UPDATE_VERSION.lower(), AKS_ENDPOINT_TYPE.lower(),
                                   subscription_id, cpu_cores_limit=cpu_cores_limit, memory_gb_limit=memory_gb_limit)


def endpoint_list(workspace_name, compute_type, model_name, model_id, tags, properties, resource_group, subscription_id, path, 
                  verbose_local, context=cli_context):
    return service_list(workspace_name, compute_type, model_name, model_id, tags, properties, None, 
                        resource_group, subscription_id, path, verbose_local, context=context)


def service_update(service_name, add_tags, remove_tags, add_properties, description, deploy_config_file,
                   path, models, model_metadata_files, inference_config_file, workspace_name, resource_group,
                   no_wait_flag, verbose_local, entry_script, runtime, conda_file, extra_docker_file_steps,
                   source_directory, enable_gpu, base_image, base_image_registry, cuda_version, cpu_cores, memory_gb,
                   location, auth_enabled, token_auth_enabled,
                   ssl_enabled, enable_app_insights, ssl_cert_pem_file, ssl_key_pem_file,
                   ssl_cname, dns_name_label, autoscale_enabled, autoscale_min_replicas, autoscale_max_replicas,
                   autoscale_refresh_seconds, autoscale_target_utilization, collect_model_data, scoring_timeout_ms,
                   replica_max_concurrent_requests, max_request_wait_time, num_replicas, primary_key, secondary_key,
                   gpu_cores, period_seconds, initial_delay_seconds, timeout_seconds, success_threshold,
                   failure_threshold, port, environment_name, environment_version, environment_directory,
                   subscription_id, cpu_cores_limit, memory_gb_limit, is_migration, compute_target, context=cli_context):

    return endpoint_service_update(service_name=service_name, add_tags=add_tags, remove_tags=remove_tags, add_properties=add_properties,
                            description=description, deploy_config_file=deploy_config_file, path=path, models=models,
                            model_metadata_files=model_metadata_files, inference_config_file=inference_config_file,
                            workspace_name=workspace_name, resource_group=resource_group,
                            subscription_id=subscription_id, no_wait_flag=no_wait_flag,
                            verbose_local=verbose_local, entry_script=entry_script, runtime=runtime,
                            conda_file=conda_file, extra_docker_file_steps=extra_docker_file_steps,
                            source_directory=source_directory, enable_gpu=enable_gpu, base_image=base_image,
                            base_image_registry=base_image_registry, cuda_version=cuda_version, cpu_cores=cpu_cores,
                            memory_gb=memory_gb, location=location, auth_enabled=auth_enabled,
                            token_auth_enabled=token_auth_enabled, ssl_enabled=ssl_enabled,
                            enable_app_insights=enable_app_insights, ssl_cert_pem_file=ssl_cert_pem_file,
                            ssl_key_pem_file=ssl_key_pem_file, ssl_cname=ssl_cname, dns_name_label=dns_name_label,
                            autoscale_enabled=autoscale_enabled, autoscale_min_replicas=autoscale_min_replicas,
                            autoscale_max_replicas=autoscale_max_replicas, autoscale_refresh_seconds=autoscale_refresh_seconds,
                            autoscale_target_utilization=autoscale_target_utilization, collect_model_data=collect_model_data,
                            scoring_timeout_ms=scoring_timeout_ms, replica_max_concurrent_requests=replica_max_concurrent_requests,
                            max_request_wait_time=max_request_wait_time, num_replicas=num_replicas, primary_key=primary_key,
                            secondary_key=secondary_key, gpu_cores=gpu_cores, period_seconds=period_seconds,
                            initial_delay_seconds=initial_delay_seconds, timeout_seconds=timeout_seconds,
                            success_threshold=success_threshold, failure_threshold=failure_threshold, port=port,
                            environment_name=environment_name, environment_version=environment_version,
                            environment_directory=environment_directory, cpu_cores_limit=cpu_cores_limit,
                            memory_gb_limit=memory_gb_limit, is_migration=is_migration, compute_target=compute_target, context=context)

def _migrate_service(workspace_name, resource_group, path, subscription_id, service_name, is_migration, compute_target, no_wait_flag, verbose_local, context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    service = None

    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            raise MlCliError('Error, no service with name {} found in workspace {} in '
                             'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))
        else:
            raise e

    if service._webservice_type.lower() != 'aks':
        raise MlCliError("Migration not support deployment type: {}".format(service._webservice_type))

    service.update(is_migration=is_migration, compute_target=compute_target)

    if no_wait_flag:
        module_logger.debug('Service migration submitted successfully.')
    else:
        service.wait_for_deployment(verbose_local)
        if service.state == 'Healthy':
            module_logger.debug('Service {} migration complete successfully'.format(service.name))
        else:
            raise MlCliError('Polling for service migration ended with service in "{}" state and with error field "{}".\n'
                             'Service name: {}\n'
                             'Workspace name: {}\n'
                             'Resource group: {}'.format(service.state, service.error, service.name, service.name,
                                                         workspace.name, workspace.resource_group))

    return service.serialize(), verbose_local

def endpoint_service_update(service_name, add_tags=None, remove_tags=None, add_properties=None, description=None,
                            deploy_config_file=None, path=None, models=None, model_metadata_files=None,
                            inference_config_file=None, workspace_name=None, resource_group=None, no_wait_flag=None,
                            verbose_local=None, entry_script=None, runtime=None, conda_file=None,
                            extra_docker_file_steps=None, source_directory=None, enable_gpu=None, base_image=None,
                            base_image_registry=None, cuda_version=None, cpu_cores=None, memory_gb=None,
                            location=None, auth_enabled=None, token_auth_enabled=None, ssl_enabled=None, enable_app_insights=None,
                            ssl_cert_pem_file=None, ssl_key_pem_file=None, ssl_cname=None, dns_name_label=None,
                            autoscale_enabled=None, autoscale_min_replicas=None, autoscale_max_replicas=None,
                            autoscale_refresh_seconds=None, autoscale_target_utilization=None, collect_model_data=None,
                            scoring_timeout_ms=None, replica_max_concurrent_requests=None, max_request_wait_time=None,
                            num_replicas=None, primary_key=None, secondary_key=None, gpu_cores=None, period_seconds=None,
                            initial_delay_seconds=None, timeout_seconds=None, success_threshold=None, failure_threshold=None,
                            port=None, environment_name=None, environment_version=None, environment_directory=None,
                            context=cli_context, version_name=None, traffic_percentile=None, is_default=None,
                            is_control_version_type=None, version_operation_type=None, expected_webservice_type=None,
                            subscription_id=None, cpu_cores_limit=None, memory_gb_limit=None, is_migration=None, compute_target=None):
    if is_migration:
        return _migrate_service(workspace_name, resource_group, path, subscription_id, service_name, 
                                is_migration, compute_target, no_wait_flag, verbose_local, context)

    if primary_key or secondary_key:
        module_logger.warning("Updating primary/secondary keys are not supported and will be ignored. "
                              "Use 'az ml service regen-key' instead.")
    if dns_name_label:
        module_logger.warning("dns-name-label parameter is deprecated and will be ignored.")

    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    service = None
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            pass
        else:
            raise e

    if service is None:
        # same name cloud service doesn't exist, check local service now
        service = try_get_local_service(workspace, service_name)

    if service is None:
        # no service exists with the input name, cloud or local. raise error
        raise MlCliError('Error, no service/endpoint with name {} found in workspace {} in '
                         'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))

    if expected_webservice_type and expected_webservice_type.lower() != service._webservice_type.lower():
        raise MlCliError('Error, no service/endpoint with name {} found in workspace {} in '
                         'resource group {} of type {}.'.format(service_name, workspace.name, workspace.resource_group,
                                                                expected_webservice_type))
    if deploy_config_file:
        try:
            with open(deploy_config_file, 'r') as deploy_file_stream:
                deploy_config_obj = file_stream_to_object(deploy_file_stream)
                if COMPUTE_TYPE_KEY in deploy_config_obj and deploy_config_obj[COMPUTE_TYPE_KEY].lower() != service._webservice_type.lower():
                    raise MlCliError('Error, no service/endpoint with name {} found in workspace {} in '
                                     'resource group {} of type {}.'.format(service_name, workspace.name,
                                                                            workspace.resource_group,
                                                                            expected_webservice_type))
        except Exception as ex:
            raise MlCliError('Error parsing --deploy-config-file. Must be valid JSON or YAML file.', content=ex)

    # handle add_tags
    tags_dict = None
    if add_tags:
        tags_dict = dict()
        for tag in add_tags:
            if '=' not in tag:
                raise MlCliError('Error, tags must be entered in the following format: key=value')
            key, value = tag.partition("=")[::2]
            tags_dict[key] = value
        if service.tags is not None:
            for key in service.tags:
                if key not in tags_dict:
                    tags_dict[key] = service.tags[key]

    # handle remove_tags
    if remove_tags:
        if service.tags is None:
            module_logger.debug('Model has no tags to remove.')
        else:
            if not tags_dict:
                tags_dict = copy.deepcopy(service.tags)
            if type(remove_tags) is not list:
                remove_tags = [remove_tags]
            for key in remove_tags:
                if key in tags_dict:
                    del tags_dict[key]
                else:
                    module_logger.debug('Tag with key {} not found.'.format(key))

    # handle add_properties
    properties_dict = None
    if add_properties:
        properties_dict = dict()
        for prop in add_properties:
            if '=' not in prop:
                raise MlCliError('Error, properties must be entered in the following format: key=value')
            key, value = prop.partition("=")[::2]
            properties_dict[key] = value

    registered_models = collect_input_models(workspace, model_metadata_files, models)

    if len(registered_models) == 0:
        registered_models = None

    # Create InferenceConfig object from input file and parameters
    inference_config = None
    # Inference config is not needed neither for endpoint update nor version delete operation.
    if not(service._webservice_type.lower() == AKS_ENDPOINT_TYPE.lower() and
           (version_operation_type == None or version_operation_type.lower() == AKS_ENDPOINT_DELETE_VERSION.lower())):
        inference_config = create_inference_config(workspace, inference_config_file, entry_script, environment_name,
                                                   environment_version, environment_directory, runtime, conda_file,
                                                   extra_docker_file_steps, source_directory, str_to_bool(enable_gpu),
                                                   description, base_image, base_image_registry, cuda_version)

    # Create deployment config object from input file and parameters
    deploy_config = create_deploy_config(deploy_config_file, service._webservice_type.lower(), cpu_cores, memory_gb,
                                         tags_dict, properties_dict, description, location, str_to_bool(auth_enabled),
                                         str_to_bool(ssl_enabled), str_to_bool(enable_app_insights), ssl_cert_pem_file,
                                         ssl_key_pem_file, ssl_cname, dns_name_label, str_to_bool(autoscale_enabled),
                                         autoscale_min_replicas, autoscale_max_replicas, autoscale_refresh_seconds,
                                         autoscale_target_utilization, str_to_bool(collect_model_data),
                                         scoring_timeout_ms, replica_max_concurrent_requests, max_request_wait_time,
                                         num_replicas, primary_key, secondary_key, tags_dict, properties_dict,
                                         gpu_cores,
                                         period_seconds, initial_delay_seconds, timeout_seconds, success_threshold,
                                         failure_threshold, None, port, str_to_bool(token_auth_enabled), None, version_name,
                                         traffic_percentile, cpu_cores_limit=cpu_cores_limit, memory_gb_limit=memory_gb_limit)

    if service._webservice_type.lower() == 'aci':
        # aci update
        service.update(image=None, tags=tags_dict, properties=properties_dict, description=description,
                       auth_enabled=deploy_config.auth_enabled,
                       ssl_enabled=deploy_config.ssl_enabled,
                       ssl_cert_pem_file=deploy_config.ssl_cert_pem_file,
                       ssl_key_pem_file=deploy_config.ssl_key_pem_file,
                       ssl_cname=deploy_config.ssl_cname,
                       enable_app_insights=deploy_config.enable_app_insights,
                       models=registered_models,
                       inference_config=inference_config)

    elif service._webservice_type.lower() == 'aks':
        # aks update
        service.update(image=None, autoscale_enabled=deploy_config.autoscale_enabled,
                       autoscale_min_replicas=deploy_config.autoscale_min_replicas,
                       autoscale_max_replicas=deploy_config.autoscale_max_replicas,
                       autoscale_refresh_seconds=deploy_config.autoscale_refresh_seconds,
                       autoscale_target_utilization=deploy_config.autoscale_target_utilization,
                       collect_model_data=deploy_config.collect_model_data,
                       auth_enabled=deploy_config.auth_enabled,
                       cpu_cores=deploy_config.cpu_cores,
                       memory_gb=deploy_config.memory_gb,
                       enable_app_insights=deploy_config.enable_app_insights,
                       scoring_timeout_ms=deploy_config.scoring_timeout_ms,
                       replica_max_concurrent_requests=deploy_config.replica_max_concurrent_requests,
                       max_request_wait_time=deploy_config.max_request_wait_time,
                       num_replicas=deploy_config.num_replicas,
                       token_auth_enabled=deploy_config.token_auth_enabled,
                       tags=tags_dict, properties=properties_dict, description=description,
                       models=registered_models, inference_config=inference_config,
                       cpu_cores_limit=deploy_config.cpu_cores_limit,
                       memory_gb_limit=deploy_config.memory_gb_limit)

    elif service._webservice_type.lower() == AKS_ENDPOINT_TYPE.lower():
        # aksendpoint update
        if version_operation_type is not None and version_operation_type.lower() == AKS_ENDPOINT_CREATE_VERSION.lower():
            service.create_version(version_name=deploy_config.version_name,
                                   autoscale_enabled=deploy_config.autoscale_enabled,
                                   autoscale_min_replicas=deploy_config.autoscale_min_replicas,
                                   autoscale_max_replicas=deploy_config.autoscale_max_replicas,
                                   autoscale_refresh_seconds=deploy_config.autoscale_refresh_seconds,
                                   autoscale_target_utilization=deploy_config.autoscale_target_utilization,
                                   collect_model_data=deploy_config.collect_model_data,
                                   cpu_cores=deploy_config.cpu_cores,
                                   memory_gb=deploy_config.memory_gb,
                                   scoring_timeout_ms=deploy_config.scoring_timeout_ms,
                                   replica_max_concurrent_requests=deploy_config.replica_max_concurrent_requests,
                                   max_request_wait_time=deploy_config.max_request_wait_time,
                                   num_replicas=deploy_config.num_replicas,
                                   tags=tags_dict, properties=properties_dict, description=description,
                                   models=registered_models, inference_config=inference_config,
                                   gpu_cores=deploy_config.gpu_cores,
                                   period_seconds=deploy_config.period_seconds,
                                   initial_delay_seconds=deploy_config.initial_delay_seconds,
                                   timeout_seconds=deploy_config.timeout_seconds,
                                   success_threshold=deploy_config.success_threshold,
                                   failure_threshold=deploy_config.failure_threshold,
                                   traffic_percentile=deploy_config.traffic_percentile, is_default=is_default,
                                   is_control_version_type=is_control_version_type,
                                   cpu_cores_limit=deploy_config.cpu_cores_limit,
                                   memory_gb_limit=deploy_config.memory_gb_limit)
        elif version_operation_type is not None and version_operation_type.lower() == AKS_ENDPOINT_DELETE_VERSION.lower():
            service.delete_version(version_name=deploy_config.version_name)
        elif version_operation_type is not None and version_operation_type.lower() == AKS_ENDPOINT_UPDATE_VERSION.lower():
            service.update_version(version_name=deploy_config.version_name,
                                   autoscale_enabled=deploy_config.autoscale_enabled,
                                   autoscale_min_replicas=deploy_config.autoscale_min_replicas,
                                   autoscale_max_replicas=deploy_config.autoscale_max_replicas,
                                   autoscale_refresh_seconds=deploy_config.autoscale_refresh_seconds,
                                   autoscale_target_utilization=deploy_config.autoscale_target_utilization,
                                   collect_model_data=deploy_config.collect_model_data,
                                   cpu_cores=deploy_config.cpu_cores,
                                   memory_gb=deploy_config.memory_gb,
                                   scoring_timeout_ms=deploy_config.scoring_timeout_ms,
                                   replica_max_concurrent_requests=deploy_config.replica_max_concurrent_requests,
                                   max_request_wait_time=deploy_config.max_request_wait_time,
                                   num_replicas=deploy_config.num_replicas,
                                   tags=tags_dict, properties=properties_dict, description=description,
                                   models=registered_models, inference_config=inference_config,
                                   gpu_cores=deploy_config.gpu_cores,
                                   period_seconds=deploy_config.period_seconds,
                                   initial_delay_seconds=deploy_config.initial_delay_seconds,
                                   timeout_seconds=deploy_config.timeout_seconds,
                                   success_threshold=deploy_config.success_threshold,
                                   failure_threshold=deploy_config.failure_threshold,
                                   traffic_percentile=deploy_config.traffic_percentile, is_default=is_default,
                                   is_control_version_type=is_control_version_type,
                                   cpu_cores_limit=deploy_config.cpu_cores_limit,
                                   memory_gb_limit=deploy_config.memory_gb_limit)
        else:
            service.update(auth_enabled=deploy_config.auth_enabled,
                           token_auth_enabled=deploy_config.token_auth_enabled,
                           enable_app_insights=deploy_config.enable_app_insights,
                           description=description, tags=tags_dict, properties=properties_dict)

    elif service._webservice_type.lower() == 'local':
        # local update
        deployment_config = LocalWebservice.deploy_configuration(port=deploy_config.port if deploy_config else None)

        service.update(models=registered_models,
                       deployment_config=deployment_config,
                       inference_config=inference_config)
    else:
        raise MlCliError("unknown deployment type: {}".format(service._webservice_type))

    if no_wait_flag:
        module_logger.debug('Service/Endpoint Update submitted successfully.')
        module_logger.debug('To see if your service/endpoint is ready to use, run:')
        module_logger.debug('  "az ml service show -n {}" or "az ml endpoint realtime show -n {}"'.format(service_name, service_name))
    else:
        service.wait_for_deployment(verbose_local)
        if service.state == 'Healthy':
            module_logger.debug('Service Name: {}'.format(service.name))
            module_logger.debug('Run your service/endpoint using "az ml service run -n {} -d <input data>" or "az ml endpoint realtime run -n {} -d <input data>"'.format(service.name, service.name))
        elif isinstance(service, LocalWebservice) and service.state == LocalWebservice.STATE_RUNNING.lower():
            module_logger.debug('Service Name: {}'.format(service.name))
            module_logger.debug('Run your service/endpoint using "az ml service run -n {} -d <input data>" or "az ml endpoint realtime run -n {} -d <input data>"'.format(service.name, service.name))
        else:
            raise MlCliError('Polling for service/endpoint update ended with service in "{}" state and with error field "{}".\n'
                             'More information can be found using "az ml service get-logs -n {}"\n'
                             'Service name: {}\n'
                             'Workspace name: {}\n'
                             'Resource group: {}'.format(service.state, service.error, service.name, service.name,
                                                         workspace.name, workspace.resource_group))

    return service.serialize(), verbose_local


def service_run(service_name, input_data, path, workspace_name, resource_group, verbose_local,
                subscription_id, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    service = None
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            pass
        else:
            raise e

    if service is None:
        # same name cloud service doesn't exist, check local service now
        service = try_get_local_service(workspace, service_name)

    if service is None:
        # no service exists with the input name, cloud or local. raise error
        raise MlCliError('Error, no service/endpoint with name {} found in workspace {} in '
                         'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))

    result = service.run(input_data)
    return result, verbose_local


def service_delete(service_name, path, workspace_name, resource_group, verbose_local,
                   subscription_id, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    service = None
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            pass
        else:
            raise e

    if service is None:
        # same name cloud service doesn't exist, check local service now
        service = try_get_local_service(workspace, service_name)

    if service is None:
        # no service exists with the input name, cloud or local. raise error
        raise MlCliError('Error, no service/endpoint with name {} found in workspace {} in '
                         'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))

    # get the image ID for this service
    image_id = None
    if service._webservice_type.lower() != AKS_ENDPOINT_TYPE.lower():
        image_id = service.image_id

    # local webservice has no underlying image
    is_local_webservice = isinstance(service, LocalWebservice)
    service.delete()

    # do not try to delete image for local webservice as there is no cloud Image for local
    if not is_local_webservice and image_id:
        image = Image(workspace, id=image_id)
        if not image or not image.id:
            raise MlCliError('Error, no model package with id {} found in workspace {} in '
                             'resource group {}.'.format(image_id, workspace.name, workspace.resource_group))
        image.delete()

    module_logger.debug('Resource deletion successfully submitted.')
    module_logger.debug('Resources may take a few minutes to be completely deprovisioned.')
    return service.serialize(), verbose_local


def service_list(workspace_name, compute_type, model_name, model_id, tags, properties,
                 image_digest, resource_group, path, verbose_local, subscription_id, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    services = Webservice.list(workspace, compute_type=compute_type, model_name=model_name, model_id=model_id,
                               tags=tags, properties=properties, image_digest=image_digest)

    return [service.serialize() for service in services], verbose_local


def service_show(service_name, path, workspace_name, resource_group, verbose_local,
                 subscription_id, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    service = None
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            pass
        else:
            raise e

    if service is None:
        # same name cloud service doesn't exist, check local service now
        service = try_get_local_service(workspace, service_name)

    if service is None:
        # no service exists with the input name, cloud or local. raise error
        raise MlCliError('Error, no service with name {} found in workspace {} in '
                         'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))

    return service.serialize(), verbose_local


def service_regen_key(service_name, key, path, workspace_name, resource_group, verbose_local, set_key,
                      subscription_id, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            raise MlCliError('Error, no service/endpoint with name {} found in workspace {} in '
                             'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))
        else:
            raise e

    if service.auth_enabled is False:
        raise MlCliError('Error, key authentication is disabled for service {}'.format(service.name))

    service.regen_key(key, set_key)

    primary_key, secondary_key = service.get_keys()

    return {
               'primaryKey': primary_key,
               'secondaryKey': secondary_key
           }, verbose_local


def service_get_keys(service_name, path, workspace_name, resource_group, verbose_local,
                     subscription_id, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            raise MlCliError('Error, no service/endpoint with name {} found in workspace {} in '
                             'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))
        else:
            raise e

    if service.auth_enabled is False:
        raise MlCliError('Error, key authentication is disabled for service {}'.format(service.name))

    primary_key, secondary_key = service.get_keys()

    return {
               'primaryKey': primary_key,
               'secondaryKey': secondary_key
           }, verbose_local


def service_get_logs(service_name, num_lines, path, workspace_name, resource_group, verbose_local,
                     subscription_id, context=cli_context, init=False):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    service = None
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            pass
        else:
            raise e

    if service is None:
        # same name cloud service doesn't exist, check local service now
        service = try_get_local_service(workspace, service_name)

    if service is None:
        # no service exists with the input name, cloud or local. raise error
        raise MlCliError('Error, no service/endpoint with name {} found in workspace {} in '
                         'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))


    logs = service.get_logs(num_lines=num_lines, init=init)

    return logs, verbose_local


def service_get_access_token(service_name, path, workspace_name, resource_group, verbose_local,
                             subscription_id, context=cli_context):
    workspace = context.get_workspace(workspace_name, resource_group, path, subscription_id)
    try:
        service = Webservice(workspace, name=service_name)
    except WebserviceException as e:
        if 'WebserviceNotFound' in e.message:
            raise MlCliError('Error, no service/endpoint with name {} found in workspace {} in '
                             'resource group {}.'.format(service_name, workspace.name, workspace.resource_group))
        else:
            raise e

    if service.token_auth_enabled is False:
        raise MlCliError('Error, token authentication is disabled for service {}'.format(service.name))

    service_token = service.get_access_token()

    return service_token.serialize(), verbose_local
