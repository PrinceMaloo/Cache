# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

# Disabling unused-import because "from . import _help" is an unused import,
# but we need this import for our help messages.

# o16n help messages.
from . import _help  # pylint: disable=unused-import

# This will load all our nice help messages for e13n CLI commands and subgroups.
# Don't remove this import.
from . import _e13n_help  # noqa # pylint: disable=unused-import

from azure.cli.core import AzCommandsLoader
import os


command_json_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'command_details.json')


def load_common_help():
    # The commands that are common between azureml._cli and az CLI.
    from azureml._cli.aml_cli import load_azurecli_help
    from knack.help_files import helps
    load_azurecli_help(helps)


load_common_help()


class MachineLearningCommandsLoader(AzCommandsLoader):
    """
    The machine learning commands loader.

    References for writing this code are:
    https://github.com/Azure/azure-cli/tree/master/src/command_modules/azure-cli-acr/azure/cli/command_modules/acr
    and
    https://github.com/Microsoft/knack
    """

    def __init__(self, cli_ctx=None):
        super(MachineLearningCommandsLoader, self).__init__(cli_ctx=cli_ctx)

    def load_command_table(self, args):
        """
        This function is called by az CLI to load commands for the machinelearning extension.
        The loaded commands are returned in a dict.
        :param args:
        :return: The command table.
        :rtype dict:
        """
        # Loading o16n commands.
        self._load_o16n_commands()

        # Loading e13n commands.
        self._load_e13n_commands(args)

        return self.command_table

    def load_arguments(self, command):
        """
        This function is called by az CLI for loading arguments of the currently
        issued CLI command.
        For a command, az CLI first calls load_command_table function, and then
        calls load_arguments function.

        This function only registers arguments for the currently issued command.
        Unlike the code inside core az CLI modules that register arguments for all
        the commands.
        Therefore, this improves the performance.
        :param command: The currently issued command.
        :type command: str
        :return: None
        """
        # TODO: Not sure if o16n checks that the command is an actual o16n command
        # and only then loads the arguments.
        self._load_o16n_arguments(command)

        self._load_e13n_arguments(command)

    def _load_o16n_commands(self):
        """
        Loads o16n commands into the AzCommandLoader table.
        :return:
        """
        from .commands import ALL_COMMANDS
        from azureml._cli_common.commands_utility import load_commands

        load_commands(self, ALL_COMMANDS, command_json_file)

    def _load_e13n_commands(self, args):
        # The commands that are base_sdk_common between azureml._cli and az CLI.
        from azureml._cli.aml_cli import load_command_table_azurecli
        load_command_table_azurecli(self, args)

    def _load_o16n_arguments(self, command):
        """
        Loads o16n command arguments.
        :param command:
        :return:
        """
        from azureml._cli_common.all_parameters import register_command_arguments
        register_command_arguments(self, command, command_json_file)

    def _load_e13n_arguments(self, command):
        """
        Loads experimentation command arguments.
        :param command:
        :return:
        """
        from azureml._cli.aml_cli import load_arguments
        load_arguments(self, command)

    def _load_datastore_arguments(self, command):
        # This function is needed to unblock linting gates for Azure CLI. The "name" argument in Datastore's commands
        # were missing help text. The change is made here as a hot fix to unblock a CLI hot fix train. Once
        # https://msdata.visualstudio.com/Vienna/_git/AzureMlCli/pullrequest/229590 has been released to pypi this
        # function can be removed.
        if not command.startswith("ml datastore"):
            return
        with self.argument_context(command) as context:
            context.argument("datastore_name", options_list=["--name", "-n"], help="The name of the datastore.")

COMMAND_LOADER_CLS = MachineLearningCommandsLoader

from azureml._base_sdk_common import __version__ as VERSION  # noqa
__version__ = VERSION

import azureml._base_sdk_common.user_agent as user_agent  # noqa
user_agent.append("azureml-cli", __version__)
