# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""
Utility functions for AML CLI
"""

from __future__ import print_function

import json
import os
import platform
import sys
import tempfile
import time

import yaml

from azureml._cli_common.ml_cli_error import MlCliError
from azureml._base_sdk_common.cli_wrapper._common import get_workspace_or_default
from azureml.core.environment import Environment
from azureml.core.webservice import LocalWebservice
from azureml.exceptions import WebserviceException
from azureml._model_management._constants import ACI_WEBSERVICE_TYPE, \
    AKS_WEBSERVICE_TYPE, AKS_ENDPOINT_TYPE, COMPUTE_TYPE_KEY

try:
    # python 3
    from urllib.request import pathname2url
    from urllib.parse import urljoin, urlparse  # pylint: disable=unused-import
    import socketserver as SocketServer
    from configparser import ConfigParser
    from builtins import input
except ImportError:
    # python 2
    from urllib import pathname2url
    from urlparse import urljoin, urlparse
    import SocketServer
    from ConfigParser import ConfigParser
    from __builtin__ import input

import subprocess
import re
import requests
from azure.cli.core._profile import Profile
from azure.cli.core.util import CLIError
from azureml._cli_common.constants import MMS_SYNC_TIMEOUT_SECONDS
from azureml._cli_common.constants import MMS_ASYNC_OPERATION_POLLING_MAX_TRIES
from azureml._cli_common.constants import MMS_ASYNC_OPERATION_POLLING_INTERVAL_SECONDS
from azureml._cli_common.constants import MMS_PAGINATED_RESPONSE_MAX_TRIES
from azureml._model_management._constants import MODEL_METADATA_FILE_ID_KEY, \
    CLI_METADATA_FILE_WORKSPACE_KEY, CLI_METADATA_FILE_RG_KEY
from azureml._model_management._util import deploy_config_dict_to_obj
from azureml.core.model import InferenceConfig
from azureml.core.model import Model
from azureml.core.webservice.aci import AciWebservice
from azureml.core.webservice.aks import AksWebservice
from azureml.core.webservice.aks import AksEndpoint
from azureml.core.webservice.local import LocalWebservice
from knack.log import get_logger
logger = get_logger(__name__)

ice_base_url = 'https://amlacsagent.azureml-int.net'
acs_connection_timeout = 5
ice_connection_timeout = 15


# EXCEPTIONS
class InvalidConfError(Exception):
    """Exception raised when config read from file is not valid json."""
    pass


# CONTEXT CLASS
class CommandLineInterfaceContext(object):
    """
    Context object that handles interaction with shell, filesystem, and azure blobs
    """
    hdi_home_regex = r'(.*:\/\/)?(?P<cluster_name>[^\s]*)'
    aml_env_default_location = 'east us'
    model_dc_storage = os.environ.get('AML_MODEL_DC_STORAGE')
    model_dc_event_hub = os.environ.get('AML_MODEL_DC_EVENT_HUB')
    hdi_home = os.environ.get('AML_HDI_CLUSTER')
    base_name = os.environ.get('AML_ROOT_NAME')
    hdi_user = os.environ.get('AML_HDI_USER', '')
    hdi_pw = os.environ.get('AML_HDI_PW', '')
    env_is_k8s = os.environ.get('AML_ACS_IS_K8S', '').lower() == 'true'


    @property
    def app_insights_account_key(self):
        if not self._app_insights_account_key:
            self._app_insights_account_key = self.get_from_mlc(('app_insights', 'instrumentation_key'))
        return self._app_insights_account_key

    @property
    def app_insights_account_id(self):
        if not self._app_insights_account_id:
            self._app_insights_account_id = self.get_from_mlc(('app_insights', 'app_id'))
        return self._app_insights_account_id

    @property
    def az_account_name(self):
        if not self._account_name:
            self._account_name = self.get_from_mlc(('storage_account', 'resource_id'))
            if self._account_name and self._account_name.startswith('/subscriptions'):
                self._account_name = self._account_name.split('/')[-1]
        return self._account_name

    @property
    def az_account_key(self):
        if not self._account_key:
            self._account_key = self.get_from_mlc(('storage_account', 'primary_key'))
        return self._account_key

    @property
    def acr_home(self):
        if not self._acr_home:
            self._acr_home = self.get_from_mlc(('container_registry', 'login_server'))
        return self._acr_home

    @property
    def acr_pw(self):
        if not self._acr_pw:
            self._acr_pw = self.get_from_mlc(('container_registry', 'password'))
        return self._acr_pw

    @property
    def acr_user(self):
        if not self._acr_user:
            if not self.acr_home:
                self._acr_user = None
            else:
                self._acr_user = self.acr_home.split('.')[0]
        return self._acr_user

    def __init__(self):
        self.env_profile_path = os.path.join(get_home_dir(), '.azure', 'viennaOperationalizationComputeResource.json')
        self.az_container_name = 'azureml'
        if self.hdi_home:
            outer_match_obj = re.match(self.hdi_home_regex, self.hdi_home)
            if outer_match_obj:
                self.hdi_home = outer_match_obj.group('cluster_name')
        self.hdi_domain = self.hdi_home.split('.')[0] if self.hdi_home else None
        self.forwarded_port = None
        self.current_execution_mode = None
        self.current_compute_creds = None
        self.current_compute_name = None
        self.current_compute_resource_group = None
        self.current_compute_subscription_id = None
        self.current_env = self.read_config()
        if self.current_env:
            self.current_execution_mode = self.current_env['current_execution_mode']
            self.current_compute_resource_group = self.current_env['resource_group']
            self.current_compute_name = self.current_env['name']
            self.current_compute_subscription_id = self.current_env['subscription']
        self._account_name = None
        self._account_key = None
        self._acr_home = None
        self._acr_pw = None
        self._acr_user = None
        self._app_insights_account_key = None
        self._app_insights_account_id = None

    @staticmethod
    def get_active_subscription_id():
        return Profile().get_subscription()['id']

    @staticmethod
    def set_active_subscription_id(sub_id):
        Profile().set_active_subscription(sub_id)
        print('Active subscription set to {}'.format(sub_id))

    def set_compute(self, compute_resource):
        self.write_config(compute_resource)
        self.current_env = compute_resource
        self.current_compute_resource_group = compute_resource['resource_group']
        self.current_compute_name = compute_resource['name']
        self.current_compute_subscription_id = compute_resource['subscription']
        self.current_execution_mode = compute_resource['current_execution_mode']

    def unset_compute(self):
        os.remove(self.env_profile_path)
        self.current_env = None
        self.current_compute_resource_group = None
        self.current_compute_name = None
        self.current_compute_subscription_id = None
        self.current_execution_mode = None

    def validate_active_and_compute_subscriptions(self):
        if (self.current_compute_subscription_id is not None and
                    self.current_compute_subscription_id != self.get_active_subscription_id()):
            print('Your current active subscription ({}) is not the same as the '
                  'subscription for your environment ({}). To proceed, you must '
                  'update your active environment.'.format(self.get_active_subscription_id(),
                                                           self.current_compute_subscription_id))
            result = input('Would you like to update your active subscription to {} [Y/n]? '.format(self.current_compute_subscription_id)).lower()
            if result == 'n' or result == 'no':
                raise MlCliError('Unable to get current compute resource from different subscription.')

            self.set_active_subscription_id(self.current_compute_subscription_id)

    def populate_compute_creds(self):
        from ._env_util import get_compute_resource_keys
        if self.current_compute_creds is None:
            if self.current_compute_name and self.current_compute_resource_group:
                self.validate_active_and_compute_subscriptions()
                try:
                    # cache credentials
                    self.current_compute_creds = get_compute_resource_keys(self.current_compute_resource_group,
                                                                           self.current_compute_name)
                except CLIError:
                    self.unset_current_compute_and_warn_user()
                    raise

    def unset_current_compute_and_warn_user(self):
        logger.warning('Unable to find env with group {} and name {}. It may have been moved or deleted, '
                       'or you could have the wrong active subscription set. Unsetting current env.'.format(
            self.current_compute_resource_group,
            self.current_compute_name))
        logger.warning("To see available environments in the subscription, run:\n"
                       "  az ml env list\n"
                       "To set an active environment, run:\n"
                       "  az ml env set -n <env_name> -g <env_group>\n"
                       "To see available subscriptions, run:\n"
                       "  az account show -o table\n"
                       "To set active accout, run:\n"
                       "  az account set -s <subscription_name>\n")
        self.unset_compute()

    def raise_for_missing_creds(self):
        raise MlCliError('Running in cluster mode is only supported with MLC RP environments. '
                         'You can provision a new environment by running: '
                         '\'az ml env setup -c -n <cluster name> -g <resource group>\'. '
                         'If you have already provisioned an environment, set it as your active environment by running:'
                         '\'az ml env set -n <cluster name> -g <resource group>\'')

    def get_from_mlc(self, cred_path):
        self.populate_compute_creds()
        if self.current_compute_creds is None:
            raise MlCliError('Unable to determine current environment information. '
                             'Please run \'az ml env set\'')

        try:
            trav = self.current_compute_creds
            for step in cred_path:
                trav = getattr(trav, step)
        except AttributeError as exc:
            raise MlCliError('Encountered an issue parsing credentials for compute. '
                             'Please contact deployml@microsoft.com with this information '
                             'if this issue persists. Raw credentials: {}'.format(self.current_compute_creds),
                             content=exc)
        return trav

    @staticmethod
    def str_from_subprocess_communicate(output):
        """

        :param output: bytes or str object
        :return: str version of output
        """
        if isinstance(output, bytes):
            return output.decode('utf-8')
        return output

    def run_cmd(self, cmd_list):
        """

        :param cmd: str command to run
        :return: str, str - std_out, std_err
        """
        proc = subprocess.Popen(cmd_list, shell=(not self.os_is_unix()),
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)
        output, err = proc.communicate()
        return self.str_from_subprocess_communicate(output), \
               self.str_from_subprocess_communicate(err)

    def read_config(self):
        """

        Tries to read in ~/.azure/viennaOperationalizationComputeResource.json as a dictionary.
        :return: dict - if successful, the config dictionary from ~/.azure/viennaOperationalizationComputeResource.json, None otherwise
        :raises: InvalidConfError if the configuration read is not valid json, or is not a dictionary
        """
        try:
            with open(self.env_profile_path, 'r') as env_file:
                try:
                    current_env = json.load(env_file)
                except ValueError as e:
                    os.remove(self.env_profile_path)
                    raise MlCliError('Error retrieving currently set environment: invalid JSON. '
                                     'Please run \'az ml env set\'')
        except IOError:
            return None
        return current_env

    def write_config(self, compute_resource):
        """

        Writes out the given configuration dictionary to ~/.azure/viennaOperationalizationComputeResource.json
        :param compute_resource: Configuration dictionary.
        :return: 0 if success, -1 otherwise
        """
        try:
            with open(self.env_profile_path, 'w') as conf_file:
                conf_file.write(json.dumps(compute_resource))
        except IOError:
            return -1

        return 0

    def in_local_mode(self):
        """
        Determines if AML CLI is running in local mode
        :return: bool - True if in local mode, false otherwise
        """

        if self.current_execution_mode:
            return self.current_execution_mode == 'local'
        else:
            raise MlCliError('Error retrieving currently set environment. '
                             'Please run \'az ml env set\'')

    @staticmethod
    def http_call(http_method, url, **kwargs):
        """

        :param http_method: str: (post|get|put|delete)
        :param url: str url to perform http call on
        :return: requests.response object
        """
        http_method = http_method.lower()

        # raises AttributeError if not a valid method
        return getattr(requests, http_method)(url, **kwargs)

    @staticmethod
    def os_is_unix():
        return platform.system().lower() in ['linux', 'unix', 'darwin']

    @staticmethod
    def get_input(input_str):
        return input(input_str)

    def check_output(self, cmd, stderr=None):
        return subprocess.check_output(cmd, shell=(not self.os_is_unix()), stderr=stderr)

    def get_workspace(self, workspace_name=None, resource_group=None, path=None, subscription_id=None):
        # if path is not provide, use current directory (.) as default value
        if not path:
            path = "."
        return get_workspace_or_default(subscription_id=subscription_id,
                                        resource_group=resource_group,
                                        workspace_name=workspace_name,
                                        project_path=path,
                                        logger=logger)


# UTILITY FUNCTIONS
def get_local_or_cloud_environment(workspace, environment_name=None, environment_version=None,
                                   environment_directory=None):
    """
    Return an Environment object which is either a cloud (already registered) or a local (not 
    registered) one, or if all inputs are None, return None.

    :param workspace: current AzML workspace
    :type workspace: azureml.core.Workspace
    :param environment_name: name of a cloud environment
    :type environment_name: string
    :param environment_version: version of a cloud environment
    :type environment_version: string
    :param environment_directory: directory of a local environment
    :type environment_directory: string
    :return: azureml.core.environment.Environment object or None
    :rtype: azureml.core.environment.Environment
    """
    # does caller provide name or directory for environment
    if environment_name is None and environment_directory is None:
        return None

    try:
        if environment_name is not None:
            # try to get registered environment by name and version
            environment = Environment.get(workspace, environment_name, environment_version)
        else:
            # try to get a local environment from input directory
            environment = Environment.load_from_directory(environment_directory)

        return environment
    except Exception as ex:
        # wrap with MlCliError
        raise MlCliError('Error getting Environment.', content=ex)


def create_inference_config(workspace, inference_config_file, entry_script, environment_name,
                            environment_version, environment_directory, runtime,
                            conda_file, extra_docker_file_steps, source_directory, enable_gpu,
                            description, base_image, base_image_registry, cuda_version):
    # create Environment object based on the environment related inputs
    environment = get_local_or_cloud_environment(workspace, environment_name, environment_version,
                                                 environment_directory)

    if inference_config_file:
        inference_config_from_file = file_to_inference_config(workspace, inference_config_file, description,
                                                              environment)
        inference_config = params_to_inference_config(entry_script, runtime, conda_file, extra_docker_file_steps,
                                                      source_directory, enable_gpu, description, base_image,
                                                      base_image_registry, cuda_version, inference_config_from_file)
    elif entry_script or environment or runtime or conda_file or extra_docker_file_steps or source_directory \
            or enable_gpu or base_image or base_image_registry or cuda_version:
        # Create InferenceConfig object from inline parameters.
        #
        # We don't do this if only description is set, because that blocks no-code deploy
        # (the description will be applied to the service itself in that case).
        inference_config = InferenceConfig(
            entry_script=entry_script, environment=environment, runtime=runtime, conda_file=conda_file,
            extra_docker_file_steps=extra_docker_file_steps, source_directory=source_directory, enable_gpu=enable_gpu,
            base_image=base_image, base_image_registry=base_image_registry, cuda_version=cuda_version,
            description=description)
    else:
        # Valid in case of no-code deploy (the SDK will sanity-check this).
        inference_config = None

    return inference_config


def create_deploy_config(deploy_config_file, compute_type, cpu_cores, memory_gb, tags_dict, properties_dict, description,
                         location, auth_enabled, ssl_enabled, enable_app_insights, ssl_cert_pem_file, ssl_key_pem_file,
                         ssl_cname, dns_name_label, autoscale_enabled, autoscale_min_replicas, autoscale_max_replicas,
                         autoscale_refresh_seconds, autoscale_target_utilization, collect_model_data, scoring_timeout_ms,
                         replica_max_concurrent_requests, max_request_wait_time, num_replicas, primary_key,
                         secondary_key, tags, properties, gpu_cores, period_seconds,
                         initial_delay_seconds, timeout_seconds, success_threshold, failure_threshold, namespace, port,
                         token_auth_enabled, compute_target_name, version_name, traffic_percentile,
                         cmk_vault_base_url=None, cmk_key_name=None, cmk_key_version=None, vnet_name=None, subnet_name=None,
                         cpu_cores_limit = None, memory_gb_limit= None):
    deploy_config = None
    if (not deploy_config_file):
        if compute_type == ACI_WEBSERVICE_TYPE.lower():
            deploy_config = AciWebservice.deploy_configuration(
                cpu_cores=cpu_cores, memory_gb=memory_gb, tags=tags_dict, properties=properties_dict,
                description=description, location=location, auth_enabled=auth_enabled, ssl_enabled=ssl_enabled,
                enable_app_insights=enable_app_insights, ssl_cert_pem_file=ssl_cert_pem_file,
                ssl_key_pem_file=ssl_key_pem_file, ssl_cname=ssl_cname, dns_name_label=dns_name_label,
                cmk_vault_base_url=cmk_vault_base_url, cmk_key_name=cmk_key_name, cmk_key_version=cmk_key_version,
                vnet_name=vnet_name, subnet_name=subnet_name, primary_key=primary_key, secondary_key=secondary_key)
        elif compute_type == AKS_WEBSERVICE_TYPE.lower():
            deploy_config = AksWebservice.deploy_configuration(
                autoscale_enabled=autoscale_enabled, autoscale_min_replicas=autoscale_min_replicas,
                autoscale_max_replicas=autoscale_max_replicas, autoscale_refresh_seconds=autoscale_refresh_seconds,
                autoscale_target_utilization=autoscale_target_utilization, collect_model_data=collect_model_data,
                auth_enabled=auth_enabled, cpu_cores=cpu_cores, memory_gb=memory_gb,
                enable_app_insights=enable_app_insights, scoring_timeout_ms=scoring_timeout_ms,
                replica_max_concurrent_requests=replica_max_concurrent_requests,
                max_request_wait_time=max_request_wait_time, num_replicas=num_replicas, primary_key=primary_key,
                secondary_key=secondary_key, tags=tags_dict, properties=properties_dict, description=description,
                gpu_cores=gpu_cores, period_seconds=period_seconds, initial_delay_seconds=initial_delay_seconds,
                timeout_seconds=timeout_seconds, success_threshold=success_threshold,
                failure_threshold=failure_threshold, namespace=namespace, token_auth_enabled=token_auth_enabled,
                compute_target_name=compute_target_name, cpu_cores_limit=cpu_cores_limit, memory_gb_limit=memory_gb_limit)
        elif compute_type == AKS_ENDPOINT_TYPE.lower():
            deploy_config = AksEndpoint.deploy_configuration(
                autoscale_enabled=autoscale_enabled, autoscale_min_replicas=autoscale_min_replicas,
                autoscale_max_replicas=autoscale_max_replicas, autoscale_refresh_seconds=autoscale_refresh_seconds,
                autoscale_target_utilization=autoscale_target_utilization, collect_model_data=collect_model_data,
                auth_enabled=auth_enabled, cpu_cores=cpu_cores, memory_gb=memory_gb,
                enable_app_insights=enable_app_insights, scoring_timeout_ms=scoring_timeout_ms,
                replica_max_concurrent_requests=replica_max_concurrent_requests,
                max_request_wait_time=max_request_wait_time, num_replicas=num_replicas, primary_key=primary_key,
                secondary_key=secondary_key, tags=tags_dict, properties=properties_dict, description=description,
                gpu_cores=gpu_cores, period_seconds=period_seconds, initial_delay_seconds=initial_delay_seconds,
                timeout_seconds=timeout_seconds, success_threshold=success_threshold,
                failure_threshold=failure_threshold, namespace=namespace, token_auth_enabled=token_auth_enabled,
                version_name=version_name, traffic_percentile=traffic_percentile,
                compute_target_name=compute_target_name, cpu_cores_limit=cpu_cores_limit, memory_gb_limit=memory_gb_limit)
        elif compute_type == "local":
            deploy_config = LocalWebservice.deploy_configuration(port=port)
    else:
        try:
            with open(deploy_config_file, 'r') as deploy_file_stream:
                deploy_config_obj = file_stream_to_object(deploy_file_stream)
                deploy_config_from_file = \
                    deploy_config_dict_to_obj(deploy_config_obj, tags_dict, properties_dict, description)
        except WebserviceException as web_service_ex:
            # Deployment config validation failure will raise WebserviceException, so we wrap it with MlCliError
            raise MlCliError('Invalid deployment configuration.', content=web_service_ex)

        if compute_type == ACI_WEBSERVICE_TYPE.lower():
            deploy_config = params_to_aci_config(cpu_cores, memory_gb, tags_dict, properties_dict, description,
                                                 location, auth_enabled, ssl_enabled, enable_app_insights,
                                                 ssl_cert_pem_file, ssl_key_pem_file, ssl_cname, dns_name_label,
                                                 cmk_vault_base_url, cmk_key_name, cmk_key_version,
                                                 vnet_name, subnet_name,
                                                 deploy_config_from_file, primary_key, secondary_key)
        elif compute_type == AKS_WEBSERVICE_TYPE.lower():
            deploy_config = params_to_aks_config(autoscale_enabled, autoscale_min_replicas, autoscale_max_replicas, autoscale_refresh_seconds,
                                                 autoscale_target_utilization, collect_model_data, auth_enabled, cpu_cores, memory_gb,
                                                 enable_app_insights, scoring_timeout_ms, replica_max_concurrent_requests, max_request_wait_time,
                                                 num_replicas, primary_key, secondary_key, tags, properties, description, gpu_cores,
                                                 period_seconds, initial_delay_seconds, timeout_seconds, success_threshold, failure_threshold,
                                                 namespace, deploy_config_from_file, token_auth_enabled, compute_target_name, cpu_cores_limit, memory_gb_limit)
        elif compute_type == AKS_ENDPOINT_TYPE.lower():
            deploy_config = params_to_aksendpoint_config(autoscale_enabled, autoscale_min_replicas, autoscale_max_replicas, autoscale_refresh_seconds,
                                                 autoscale_target_utilization, collect_model_data, auth_enabled, cpu_cores, memory_gb,
                                                 enable_app_insights, scoring_timeout_ms, replica_max_concurrent_requests, max_request_wait_time,
                                                 num_replicas, primary_key, secondary_key, tags, properties, description, gpu_cores,
                                                 period_seconds, initial_delay_seconds, timeout_seconds, success_threshold, failure_threshold,
                                                 namespace, deploy_config_from_file, token_auth_enabled, compute_target_name, version_name, traffic_percentile,
                                                 cpu_cores_limit, memory_gb_limit)
        elif compute_type == "local":
            deploy_config = params_to_local_config(port, deploy_config_from_file)
    return deploy_config


def file_to_inference_config(workspace, inference_config_file, description, environment_input=None):
    """Takes an inference_config_file and returns the InferenceConfig object
    :param workspace: current AzML workspace
    :type workspace: azureml.core.Workspace
    :param inference_config_file: Input file with InferenceConfig parameters
    :type inference_config_file: varies
    :param description: description for the InferenceConfig.
    :type description: string
    :param environment_input: Environment object to use for the image.
    :type environment_input: azureml.core.Environment or None
    :return: InferenceConfig object
    :rtype: azureml.core.model.InferenceConfig
    """
    try:
        with open(inference_config_file) as inference_file_stream:
            inference_config_obj = file_stream_to_object(inference_file_stream)

            # Retrieve Environment object from the InferenceConfig file
            inference_config_environment = inference_config_obj.get('environment')
            environment = None
            if inference_config_environment is None:
                environment = environment_input
            else:
                # deserialize into Environment object
                environment = Environment._deserialize_and_add_to_object(inference_config_environment)


            inference_config = InferenceConfig(
                entry_script = inference_config_obj.get('entryScript'),
                runtime = inference_config_obj.get('runtime'),
                conda_file = inference_config_obj.get('condaFile'),
                extra_docker_file_steps = inference_config_obj.get('extraDockerfileSteps'),
                source_directory = inference_config_obj.get('sourceDirectory'),
                enable_gpu = inference_config_obj.get('enableGpu'),
                base_image = inference_config_obj.get('baseImage'),
                base_image_registry = inference_config_obj.get('baseImageRegistry'),
                cuda_version = inference_config_obj.get('cudaVersion'),
                environment = environment,
                description = description)
            return inference_config
    except WebserviceException as web_service_ex:
        # InferenceConfig validation failure will raise WebserviceException, so we wrap it with MlCliError
        raise MlCliError('Invalid inference configuration.', content=web_service_ex)
    except Exception as ex:
        raise MlCliError('Error parsing --inference-config-file. Must be valid JSON or YAML file.', content=ex)


def file_stream_to_object(file_stream):
    """Expects a YAML or JSON file_stream and returns the file object
    :param file_stream: File stream from with open(file) as file_stream
    :type file_stream:
    :return: File dictionary
    :rtype: dict
    """
    file_data = file_stream.read()

    try:
        return yaml.safe_load(file_data)
    except Exception as ex:
        pass

    try:
        return json.loads(file_data)
    except Exception as ex:
        raise MlCliError('Error while parsing file. Must be valid JSON or YAML file.', content=ex)


def params_to_inference_config(entry_script, runtime, conda_file, extra_docker_file_steps, source_directory,
                               enable_gpu, description, base_image, base_image_registry, cuda_version,
                               config_from_file):
    """Takes inference config parameters and returns an InferenceConfig object.
    The parameters in this method will overwrite attributes from the config
    :param entry_script: Path to local file that contains the code to run for the image
    :type entry_script: str
    :param runtime: Which runtime to use for the image. Current supported runtimes are 'spark-py' and 'python'
    :type runtime: str
    :param conda_file: Path to local file containing a conda environment definition to use for the image
    :type conda_file: str
    :param extra_docker_file_steps: Path to local file containing extra Docker steps to run when setting up image
    :type extra_docker_file_steps: str
    :param source_directory: paths to folders that contains all files to create the image
    :type source_directory: : str
    :param enable_gpu: Whether or not to enable GPU support in the image. The GPU image must be used on
        Microsoft Azure Services such as Azure Container Instances, Azure Machine Learning Compute,
        Azure Virtual Machines, and Azure Kubernetes Service.  Defaults to False
    :type enable_gpu: bool
    :param description: A description to give this image
    :type description: str
    :param base_image: A custom image to be used as base image. If no base image is given then the base image
        will be used based off of given runtime parameter.
    :type base_image: str
    :param base_image_registry: Image registry that contains the base image.
    :type base_image_registry: azureml.core.container_registry.ContainerRegistry
    :param cuda_version: Version of CUDA to install for images that need GPU support. The GPU image must be used on
        Microsoft Azure Services such as Azure Container Instances, Azure Machine Learning Compute,
        Azure Virtual Machines, and Azure Kubernetes Service. Supported versions are 9.0, 9.1, and 10.0.
        If 'enable_gpu' is set, this defaults to '9.1'.
    :type cuda_version: str
    :param config_from_file: Attributes from this object will be used to create the new InferenceConfig object.
        Parameters provided to this method take precedence over the attributes given by this config object parameter
    :type config_from_file: azureml.core.model.InferenceConfig
    :return: InferenceConfig object
    :rtype: azureml.core.model.InferenceConfig
    """
    return InferenceConfig(
        entry_script=entry_script or config_from_file.entry_script,
        runtime=runtime or config_from_file.runtime,
        conda_file=conda_file or config_from_file.conda_file,
        extra_docker_file_steps=extra_docker_file_steps or config_from_file.extra_docker_file_steps,
        source_directory=source_directory or config_from_file.source_directory,
        enable_gpu=enable_gpu or config_from_file.enable_gpu,
        base_image=base_image or config_from_file.base_image,
        base_image_registry=base_image_registry or config_from_file.base_image_registry,
        cuda_version=cuda_version or config_from_file.cuda_version,
        environment=config_from_file.environment,
        description=description or config_from_file.description)


def params_to_aci_config(cpu_cores, memory_gb, tags_dict, properties_dict, description, location, auth_enabled, ssl_enabled,
                         enable_app_insights, ssl_cert_pem_file, ssl_key_pem_file, ssl_cname, dns_name_label,
                         cmk_vault_base_url, cmk_key_name, cmk_key_version,
                         vnet_name, subnet_name, config_from_file, primary_key, secondary_key):
    """Takes aci config parameters and returns an AciServiceDeploymentConfiguration object.
    The parameters in this method will overwrite attributes from the config
    :param cpu_cores: The number of cpu cores to allocate for this Webservice. Can be a decimal. Defaults to 0.1
    :type cpu_cores: float
    :param memory_gb: The amount of memory (in GB) to allocate for this Webservice. Can be a decimal.
        Defaults to 0.5
    :type memory_gb: float
    :param tags_dict: Dictionary of key value tags to give this Webservice
    :type tags_dict: dict[str, str]
    :param properties_dict: Dictionary of key value properties to give this Webservice. These properties cannot
        be changed after deployment, however new key value pairs can be added
    :type properties_dict: dict[str, str]
    :param description: A description to give this Webservice
    :type description: str
    :param location: The Azure region to deploy this Webservice to. If not specified the Workspace location will
        be used. More details on available regions can be found here:
        https://azure.microsoft.com/en-us/global-infrastructure/services/?regions=all&products=container-instances
    :type location: str
    :param auth_enabled: Whether or not to enable auth for this Webservice. Defaults to False
    :type auth_enabled: bool
    :param ssl_enabled: Whether or not to enable SSL for this Webservice. Defaults to False
    :type ssl_enabled: bool
    :param enable_app_insights: Whether or not to enable AppInsights for this Webservice. Defaults to False
    :type enable_app_insights: bool
    :param ssl_cert_pem_file: The cert file needed if SSL is enabled
    :type ssl_cert_pem_file: str
    :param ssl_key_pem_file: The key file needed if SSL is enabled
    :type ssl_key_pem_file: str
    :param ssl_cname: The cname for if SSL is enabled
    :type ssl_cname: str
    :param dns_name_label: The dns name label for the scoring endpoint.
        If not specified a unique dns name label will be generated for the scoring endpoint.
    :type dns_name_label: str
    :param cmk_vault_base_url: customer managed key vault base url
    :type cmk_vault_base_url: str
    :param cmk_key_name: customer managed key name.
    :type cmk_key_name: str
    :param cmk_key_version: customer managed key version.
    :type cmk_key_version: str
    :param vnet_name: virtual network name.
    :type vnet_name: str
    :param subnet_name: subnet_name name within virtual network.
    :type subnet_name: str
    :param config_from_file: Attributes from this object will be used to create the new AciServiceDeploymentConfiguration object.
        Parameters provided to this method take precedence over the attributes given by this config object parameter
    :type config_from_file: azureml.core.webservice.aci.AciServiceDeploymentConfiguration
    :param primary_key: A primary auth key to use for this Webservice
    :type primary_key: str
    :param secondary_key: A secondary auth key to use for this Webservice
    :type secondary_key: str
    :return: AciServiceDeploymentConfiguration object
    :rtype: azureml.core.webservice.aci.AciServiceDeploymentConfiguration
    """
    return AciWebservice.deploy_configuration(
        cpu_cores = cpu_cores if cpu_cores else config_from_file.cpu_cores,
        memory_gb = memory_gb if memory_gb else config_from_file.memory_gb,
        tags = tags_dict,
        properties = properties_dict,
        description = description if description else config_from_file.description,
        location = location if location else config_from_file.location,
        auth_enabled = auth_enabled if auth_enabled is not None else config_from_file.auth_enabled,
        ssl_enabled = ssl_enabled if ssl_enabled is not None else config_from_file.ssl_enabled,
        enable_app_insights = enable_app_insights if enable_app_insights is not None else config_from_file.enable_app_insights,
        ssl_cert_pem_file = ssl_cert_pem_file if ssl_cert_pem_file else config_from_file.ssl_cert_pem_file,
        ssl_key_pem_file = ssl_key_pem_file if ssl_key_pem_file else config_from_file.ssl_key_pem_file,
        ssl_cname = ssl_cname if ssl_cname else config_from_file.ssl_cname,
        dns_name_label = dns_name_label if dns_name_label else config_from_file.dns_name_label,
        cmk_vault_base_url = cmk_vault_base_url if cmk_vault_base_url else config_from_file.cmk_vault_base_url,
        cmk_key_name = cmk_key_name if cmk_key_name else config_from_file.cmk_key_name,
        cmk_key_version = cmk_key_version if cmk_key_version else config_from_file.cmk_key_version,
        vnet_name = vnet_name if vnet_name else config_from_file.vnet_name,
        subnet_name = subnet_name if subnet_name else config_from_file.subnet_name,
        primary_key = primary_key if primary_key else config_from_file.primary_key,
        secondary_key = secondary_key if secondary_key else config_from_file.secondary_key)


def params_to_aks_config(autoscale_enabled, autoscale_min_replicas, autoscale_max_replicas, autoscale_refresh_seconds,
                         autoscale_target_utilization, collect_model_data, auth_enabled, cpu_cores, memory_gb,
                         enable_app_insights, scoring_timeout_ms, replica_max_concurrent_requests,
                         max_request_wait_time, num_replicas, primary_key, secondary_key, tags, properties,
                         description, gpu_cores, period_seconds, initial_delay_seconds, timeout_seconds,
                         success_threshold, failure_threshold, namespace, config_from_file, token_auth_enabled,
                         compute_target_name, cpu_cores_limit, memory_gb_limit):
    """Takes aks config parameters and returns an AksServiceDeploymentConfiguration object.
    The parameters in this method will overwrite attributes from the config
    :param autoscale_enabled: Whether or not to enable autoscaling for this Webservice.
        Defaults to True if num_replicas is None
    :type autoscale_enabled: bool
    :param autoscale_min_replicas: The minimum number of containers to use when autoscaling this Webservice.
        Defaults to 1
    :type autoscale_min_replicas: int
    :param autoscale_max_replicas: The maximum number of containers to use when autoscaling this Webservice.
        Defaults to 10
    :type autoscale_max_replicas: int
    :param autoscale_refresh_seconds: How often the autoscaler should attempt to scale this Webservice.
        Defaults to 1
    :type autoscale_refresh_seconds: int
    :param autoscale_target_utilization: The target utilization (in percent out of 100) the autoscaler should
        attempt to maintain for this Webservice. Defaults to 70
    :type autoscale_target_utilization: int
    :param collect_model_data: Whether or not to enable model data collection for this Webservice.
        Defaults to False
    :type collect_model_data: bool
    :param auth_enabled: Whether or not to enable auth for this Webservice. Defaults to True
    :type auth_enabled: bool
    :param cpu_cores: The number of cpu cores to allocate for this Webservice. Can be a decimal. Defaults to 0.1
    :type cpu_cores: float
    :param memory_gb: The amount of memory (in GB) to allocate for this Webservice. Can be a decimal.
        Defaults to 0.5
    :type memory_gb: float
    :param enable_app_insights: Whether or not to enable Application Insights logging for this Webservice.
        Defaults to False
    :type enable_app_insights: bool
    :param scoring_timeout_ms: A timeout to enforce for scoring calls to this Webservice. Defaults to 60000
    :type scoring_timeout_ms: int
    :param replica_max_concurrent_requests: The number of maximum concurrent requests per node to allow for this
        Webservice. Defaults to 1
    :type replica_max_concurrent_requests: int
    :param max_request_wait_time: The maximum amount of time a request will stay in the queue (in milliseconds)
        before returning a 503 error. Defaults to 500
    :type max_request_wait_time: int
    :param num_replicas: The number of containers to allocate for this Webservice. No default, if this parameter
        is not set then the autoscaler is enabled by default.
    :type num_replicas: int
    :param primary_key: A primary auth key to use for this Webservice
    :type primary_key: str
    :param secondary_key: A secondary auth key to use for this Webservice
    :type secondary_key: str
    :param tags: Dictionary of key value tags to give this Webservice
    :type tags: dict[str, str]
    :param properties: Dictionary of key value properties to give this Webservice. These properties cannot
        be changed after deployment, however new key value pairs can be added
    :type properties: dict[str, str]
    :param description: A description to give this Webservice
    :type description: str
    :param gpu_cores: The number of gpu cores to allocate for this Webservice. Defaults to 0.
    :type gpu_cores: int
    :param period_seconds: How often (in seconds) to perform the liveness probe. Default to 10 seconds.
        Minimum value is 1.
    :type period_seconds: int
    :param initial_delay_seconds: Number of seconds after the container has started before liveness probes are
        initiated. Defaults to 310
    :type initial_delay_seconds: int
    :param timeout_seconds: Number of seconds after which the liveness probe times out. Defaults to 2 second.
        Minimum value is 1
    :type timeout_seconds: int
    :param success_threshold: Minimum consecutive successes for the liveness probe to be considered successful
        after having failed. Defaults to 1. Minimum value is 1.
    :type success_threshold: int
    :return: A configuration object to use when
    :param failure_threshold: When a Pod starts and the liveness probe fails, Kubernetes will try failureThreshold
        times before giving up. Defaults to 3. Minimum value is 1.
    :type failure_threshold: int deploying a Webservice object
    :param namespace: The Kubernetes namespace in which to deploy this Webservice: up to 63 lowercase alphanumeric
        ('a'-'z', '0'-'9') and hyphen ('-') characters. The first and last characters cannot be hyphens.
    :type namespace: str
    :param config_from_file: Attributes from this object will be used to create the new AksServiceDeploymentConfiguration object.
        Parameters provided to this method take precedence over the attributes given by this config object parameter
    :type config_from_file: azureml.core.webservice.aks.AksServiceDeploymentConfiguration
    :param token_auth_enabled: Whether or not to enable Token auth for this Webservice. If this is
            enabled, users can access this Webservice by fetching access token using their Azure Active Directory
            credentials. Defaults to False
    :type token_auth_enabled: bool
    :param compute_target_name: The name of the compute target to deploy to
    :type compute_target_name: str
    :var cpu_cores_limit: The max number of CPU cores this Webservice is allowed to use. Can be a decimal.
    :type cpu_cores_limit: float
    :var memory_in_gb_limit: The max amount of memory (in GB) this Webservice is allowed to use. Can be a decimal.
    :type memory_in_gb_limit: float
    :return: AksServiceDeploymentConfiguration object
    :rtype: azureml.core.webservice.aks.AksServiceDeploymentConfiguration
    """
    return AksWebservice.deploy_configuration(
        autoscale_enabled = autoscale_enabled if autoscale_enabled is not None else config_from_file.autoscale_enabled,
        autoscale_min_replicas = autoscale_min_replicas if autoscale_min_replicas else config_from_file.autoscale_min_replicas,
        autoscale_max_replicas = autoscale_max_replicas if autoscale_max_replicas else config_from_file.autoscale_max_replicas,
        autoscale_refresh_seconds = autoscale_refresh_seconds if autoscale_refresh_seconds else config_from_file.autoscale_refresh_seconds,
        autoscale_target_utilization = autoscale_target_utilization if autoscale_target_utilization else config_from_file.autoscale_target_utilization,
        collect_model_data = collect_model_data if collect_model_data is not None else config_from_file.collect_model_data,
        auth_enabled = auth_enabled if auth_enabled is not None else config_from_file.auth_enabled,
        cpu_cores = cpu_cores if cpu_cores else config_from_file.cpu_cores,
        memory_gb = memory_gb if memory_gb else config_from_file.memory_gb,
        enable_app_insights = enable_app_insights if enable_app_insights is not None else config_from_file.enable_app_insights,
        scoring_timeout_ms = scoring_timeout_ms if scoring_timeout_ms else config_from_file.scoring_timeout_ms,
        replica_max_concurrent_requests = replica_max_concurrent_requests if replica_max_concurrent_requests else config_from_file.replica_max_concurrent_requests,
        max_request_wait_time = max_request_wait_time if max_request_wait_time else config_from_file.max_request_wait_time,
        num_replicas = num_replicas if num_replicas else config_from_file.num_replicas,
        primary_key = primary_key if primary_key else config_from_file.primary_key,
        secondary_key = secondary_key if secondary_key else config_from_file.secondary_key,
        tags = tags if tags else config_from_file.tags,
        properties = properties if properties else config_from_file.properties,
        description = description if description else config_from_file.description,
        gpu_cores = gpu_cores if gpu_cores else config_from_file.gpu_cores,
        period_seconds = period_seconds if period_seconds else config_from_file.period_seconds,
        initial_delay_seconds = initial_delay_seconds if initial_delay_seconds else config_from_file.initial_delay_seconds,
        timeout_seconds = timeout_seconds if timeout_seconds else config_from_file.timeout_seconds,
        success_threshold = success_threshold if success_threshold else config_from_file.success_threshold,
        failure_threshold = failure_threshold if failure_threshold else config_from_file.failure_threshold,
        namespace = namespace if namespace else config_from_file.namespace,
        token_auth_enabled= token_auth_enabled if token_auth_enabled is not None else config_from_file.token_auth_enabled,
        compute_target_name=compute_target_name if compute_target_name is not None else config_from_file.compute_target_name,
        cpu_cores_limit = cpu_cores_limit if cpu_cores_limit else config_from_file.cpu_cores_limit,
        memory_gb_limit = memory_gb_limit if memory_gb_limit else config_from_file.memory_gb_limit)

def params_to_aksendpoint_config(autoscale_enabled, autoscale_min_replicas, autoscale_max_replicas, autoscale_refresh_seconds,
                         autoscale_target_utilization, collect_model_data, auth_enabled, cpu_cores, memory_gb,
                         enable_app_insights, scoring_timeout_ms, replica_max_concurrent_requests,
                         max_request_wait_time, num_replicas, primary_key, secondary_key, tags, properties,
                         description, gpu_cores, period_seconds, initial_delay_seconds, timeout_seconds,
                         success_threshold, failure_threshold, namespace, config_from_file, token_auth_enabled,
                         compute_target_name, version_name, traffic_percentile, cpu_cores_limit, memory_gb_limit):
    """Takes aks config parameters and returns an AksEndpointDeploymentConfiguration object.
    The parameters in this method will overwrite attributes from the config
    :param autoscale_enabled: Whether or not to enable autoscaling for this Version.
        Defaults to True if num_replicas is None
    :type autoscale_enabled: bool
    :param autoscale_min_replicas: The minimum number of containers to use when autoscaling this Version.
        Defaults to 1
    :type autoscale_min_replicas: int
    :param autoscale_max_replicas: The maximum number of containers to use when autoscaling this Version.
        Defaults to 10
    :type autoscale_max_replicas: int
    :param autoscale_refresh_seconds: How often the autoscaler should attempt to scale this Version.
        Defaults to 1
    :type autoscale_refresh_seconds: int
    :param autoscale_target_utilization: The target utilization (in percent out of 100) the autoscaler should
        attempt to maintain for this Version. Defaults to 70
    :type autoscale_target_utilization: int
    :param collect_model_data: Whether or not to enable model data collection for this Version.
        Defaults to False
    :type collect_model_data: bool
    :param auth_enabled: Whether or not to enable auth for this Endpoint. Defaults to True
    :type auth_enabled: bool
    :param cpu_cores: The number of cpu cores to allocate for this Version. Can be a decimal. Defaults to 0.1
    :type cpu_cores: float
    :param memory_gb: The amount of memory (in GB) to allocate for this Version. Can be a decimal.
        Defaults to 0.5
    :type memory_gb: float
    :param enable_app_insights: Whether or not to enable Application Insights logging for this Endpoint.
        Defaults to False
    :type enable_app_insights: bool
    :param scoring_timeout_ms: A timeout to enforce for scoring calls to this Version. Defaults to 60000
    :type scoring_timeout_ms: int
    :param replica_max_concurrent_requests: The number of maximum concurrent requests per node to allow for this
        Version. Defaults to 1
    :type replica_max_concurrent_requests: int
    :param max_request_wait_time: The maximum amount of time a request will stay in the queue (in milliseconds)
        before returning a 503 error. Defaults to 500
    :type max_request_wait_time: int
    :param num_replicas: The number of containers to allocate for this Version. No default, if this parameter
        is not set then the autoscaler is enabled by default.
    :type num_replicas: int
    :param primary_key: A primary auth key to use for this Endpoint
    :type primary_key: str
    :param secondary_key: A secondary auth key to use for this Endpoint
    :type secondary_key: str
    :param tags: Dictionary of key value tags to give this Version
    :type tags: dict[str, str]
    :param properties: Dictionary of key value properties to give this Version. These properties cannot
        be changed after deployment, however new key value pairs can be added
    :type properties: dict[str, str]
    :param description: A description to give this Endpoint
    :type description: str
    :param gpu_cores: The number of gpu cores to allocate for this Version. Defaults to 0.
    :type gpu_cores: int
    :param period_seconds: How often (in seconds) to perform the liveness probe. Default to 10 seconds.
        Minimum value is 1.
    :type period_seconds: int
    :param initial_delay_seconds: Number of seconds after the container has started before liveness probes are
        initiated. Defaults to 310
    :type initial_delay_seconds: int
    :param timeout_seconds: Number of seconds after which the liveness probe times out. Defaults to 2 second.
        Minimum value is 1
    :type timeout_seconds: int
    :param success_threshold: Minimum consecutive successes for the liveness probe to be considered successful
        after having failed. Defaults to 1. Minimum value is 1.
    :type success_threshold: int
    :return: A configuration object to use when
    :param failure_threshold: When a Pod starts and the liveness probe fails, Kubernetes will try failureThreshold
        times before giving up. Defaults to 3. Minimum value is 1.
    :type failure_threshold: int deploying a Version object
    :param namespace: The Kubernetes namespace in which to deploy this Version: up to 63 lowercase alphanumeric
        ('a'-'z', '0'-'9') and hyphen ('-') characters. The first and last characters cannot be hyphens.
    :type namespace: str
    :param config_from_file: Attributes from this object will be used to create the new AksEndpointDeploymentConfiguration object.
        Parameters provided to this method take precedence over the attributes given by this config object parameter
    :type config_from_file: azureml.core.webservice.aks.AksEndpointDeploymentConfiguration
    :param token_auth_enabled: Whether or not to enable Token auth for this Endpoint. If this is
            enabled, users can access this Endpoint by fetching access token using their Azure Active Directory
            credentials. Defaults to False
    :type token_auth_enabled: bool
    :param version_name: The name of the version in an endpoint.
    :type version_name: str
    :param traffic_percentile: the amount of traffic the version takes in an endpoint.
    :type traffic_percentile: float
    :param cpu_cores_limit: The max number of CPU cores this Webservice is allowed to use. Can be a decimal.
    :type cpu_cores_limit: float
    :param memory_in_gb_limit: The max amount of memory (in GB) this Webservice is allowed to use. Can be a decimal.
    :type memory_in_gb_limit: float
    :return: AksEndpointDeploymentConfiguration object
    :rtype: azureml.core.webservice.aks.AksEndpointDeploymentConfiguration
    """
    return AksEndpoint.deploy_configuration(
        autoscale_enabled = autoscale_enabled if autoscale_enabled is not None else config_from_file.autoscale_enabled,
        autoscale_min_replicas = autoscale_min_replicas if autoscale_min_replicas else config_from_file.autoscale_min_replicas,
        autoscale_max_replicas = autoscale_max_replicas if autoscale_max_replicas else config_from_file.autoscale_max_replicas,
        autoscale_refresh_seconds = autoscale_refresh_seconds if autoscale_refresh_seconds else config_from_file.autoscale_refresh_seconds,
        autoscale_target_utilization = autoscale_target_utilization if autoscale_target_utilization else config_from_file.autoscale_target_utilization,
        collect_model_data = collect_model_data if collect_model_data is not None else config_from_file.collect_model_data,
        auth_enabled = auth_enabled if auth_enabled is not None else config_from_file.auth_enabled,
        cpu_cores = cpu_cores if cpu_cores else config_from_file.cpu_cores,
        memory_gb = memory_gb if memory_gb else config_from_file.memory_gb,
        enable_app_insights = enable_app_insights if enable_app_insights is not None else config_from_file.enable_app_insights,
        scoring_timeout_ms = scoring_timeout_ms if scoring_timeout_ms else config_from_file.scoring_timeout_ms,
        replica_max_concurrent_requests = replica_max_concurrent_requests if replica_max_concurrent_requests else config_from_file.replica_max_concurrent_requests,
        max_request_wait_time = max_request_wait_time if max_request_wait_time else config_from_file.max_request_wait_time,
        num_replicas = num_replicas if num_replicas else config_from_file.num_replicas,
        primary_key = primary_key if primary_key else config_from_file.primary_key,
        secondary_key = secondary_key if secondary_key else config_from_file.secondary_key,
        tags = tags if tags else config_from_file.tags,
        properties = properties if properties else config_from_file.properties,
        description = description if description else config_from_file.description,
        gpu_cores = gpu_cores if gpu_cores else config_from_file.gpu_cores,
        period_seconds = period_seconds if period_seconds else config_from_file.period_seconds,
        initial_delay_seconds = initial_delay_seconds if initial_delay_seconds else config_from_file.initial_delay_seconds,
        timeout_seconds = timeout_seconds if timeout_seconds else config_from_file.timeout_seconds,
        success_threshold = success_threshold if success_threshold else config_from_file.success_threshold,
        failure_threshold = failure_threshold if failure_threshold else config_from_file.failure_threshold,
        namespace = namespace if namespace else config_from_file.namespace,
        token_auth_enabled= token_auth_enabled if token_auth_enabled is not None else config_from_file.token_auth_enabled,
        version_name = version_name if version_name is not None else config_from_file.version_name,
        traffic_percentile = traffic_percentile if traffic_percentile is not None else config_from_file.traffic_percentile,
        compute_target_name=compute_target_name if compute_target_name is not None else config_from_file.compute_target_name,
        cpu_cores_limit = cpu_cores_limit if cpu_cores_limit else config_from_file.cpu_cores_limit,
        memory_gb_limit = memory_gb_limit if memory_gb_limit else config_from_file.memory_gb_limit)

def params_to_local_config(port, config_from_file):
    """Takes local config parameters and returns an LocalWebserviceDeploymentConfiguration object.
    The parameters in this method will overwrite attributes from the config
    :param port: The local port on which to expose the service's HTTP endpoint.
    :type port: int
    :param config_from_file: Attributes from this object will be used to create the new LocalWebserviceDeploymentConfiguration object.
        Parameters provided to this method take precedence over the attributes given by this config object parameter
    :type config_from_file: azureml.core.webservice.aci.LocalWebserviceDeploymentConfiguration
    :return: LocalWebserviceDeploymentConfiguration object
    :rtype: azureml.core.webservice.local.LocalWebserviceDeploymentConfiguration
    """
    return LocalWebservice.deploy_configuration(port = port if port else config_from_file.port)


def collect_input_models(workspace, model_metadata_files, models):
    registered_models = []

    if model_metadata_files:
        for model_meta_file in model_metadata_files:
            with open(model_meta_file, 'r') as infile:
                model_metadata = json.load(infile)
                if model_metadata[CLI_METADATA_FILE_WORKSPACE_KEY] != workspace.name or \
                        model_metadata[CLI_METADATA_FILE_RG_KEY] != workspace.resource_group:
                    raise MlCliError('Model metadata file \'{}\' contains information for a model in a workspace '
                                     'that does not match the one provided for model packaging. If the model '
                                     'specified in the file is intended to be used, please either register it '
                                     'in the workspace provided to this command, or specify the corresponding '
                                     'workspace to this command.'.format(model_meta_file))
                registered_models.append(
                    Model(workspace, id=model_metadata[MODEL_METADATA_FILE_ID_KEY]))

    if models:
        for model_id in models:
            registered_models.append(Model(workspace, id=model_id))

    return registered_models


def parse_options(tags, name):
    tags_dict = None
    if tags:
        tags_dict = dict()
        for tag in tags:
            if '=' not in tag:
                raise MlCliError('Error, {} must be entered in the following format: key=value'.format(name))
            key, value = tag.partition("=")[::2]
            tags_dict[key] = value
    return tags_dict


def parse_tags(tags):
    return parse_options(tags, "tags")

def get_identity_values(identity):
    identity_type = None
    identity_id = None
    if identity:
        identity_type= "SystemAssigned" if identity=="[system]" else "UserAssigned"
        identity_id = identity.split(",") if identity_type == "UserAssigned" else None
    return identity_type, identity_id


def parse_properties(props):
    return parse_options(props, "properties")


def get_json(payload, pascal=False):
    """
    Handles decoding JSON to python objects in py2, py3
    :param payload: str/bytes json to decode
    :return: dict/list/str that represents json
    """
    if isinstance(payload, bytes):
        payload = payload.decode('utf-8')
    payload = json.loads(payload) if payload else {}
    if pascal:
        payload = to_pascal(payload)
    return payload


def get_home_dir():
    """
    Function to find home directory on windows or linux environment
    :return: str - path to home directory
    """
    return os.path.expanduser('~')


cli_context = CommandLineInterfaceContext()


def print_util(msg, verb):
    if verb:
        print(msg)


def traverse_json(json_obj, traversal_tuple):
    """
        Example:
            {
                "ID": "12345",
                "Properties" {
                    "Name": "a_service"
                }
            }

            If we wanted the "Name" property of the above json to be displayed, we would use the traversal_tuple
                ("Properties", "Name")

        NOTE that list traversal is not supported here, but can work in the case that
        a valid numerical index is passed in the tuple

    :param json_obj: json_obj to traverse. nested dictionaries--lists not supported
    :param traversal_tuple: tuple of keys to traverse the json dict
    :return: string value to display
    """
    trav = to_pascal(json_obj)
    for key in traversal_tuple:
        trav = trav[key]
    return trav


class ValueFunction(object):
    """
    Abstract class for use finding the appropriate value for a given property in a json response.
         defines set_json, a function for storing the json response we will format
         declares evaluate, a function for retrieving the formatted string
    """

    def __init__(self):
        self.json_obj = None

    def set_json(self, json_obj):
        """

        :param json_obj: list or dict to store for processing
        :return: ValueFunction the "self" object with newly updated json_obj member
        """
        self.json_obj = json_obj
        return self

    def evaluate(self, context):
        """

        :param context:
        :return: str value to display
        """
        raise NotImplementedError("Class does not implement evaluate method.")


class TraversalFunction(ValueFunction):
    """
    ValueFunction that consumes a traversal tuple to locate the appropriate string for display
        Example:
            {
                "ID": "12345",
                "Properties" {
                    "Name": "a_service"
                }
            }

            If we wanted the "Name" property of the above json to be displayed, we would use the traversal_tuple
                ("Properties", "Name")

        NOTE that list traversal is not supported here.
    """

    def __init__(self, tup):
        super(TraversalFunction, self).__init__()
        self.traversal_tup = tup

    def evaluate(self, context):
        return traverse_json(self.json_obj, self.traversal_tup)


class ConditionalListTraversalFunction(TraversalFunction):
    """
    Class for use executing actions on members of a list that meet certain criteria
    """

    def __init__(self, tup, condition, action):
        super(ConditionalListTraversalFunction, self).__init__(tup)
        self.condition = condition
        self.action = action

    def evaluate(self, context):
        json_list = super(ConditionalListTraversalFunction, self).evaluate(context)
        return ', '.join(
            [self.action(item) for item in json_list if self.condition(item)])


def to_pascal(obj):
    """ Make dictionary PascalCase """
    if isinstance(obj, dict):
        return {k[0].upper() + k[1:]: to_pascal(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [to_pascal(k) for k in obj]
    return obj


def add_sdk_to_requirements(requirements):
    # always pass sdk as dependency to mms/ICE.
    # Add the version required by the installed CLI.
    generated_requirements = tempfile.mkstemp(suffix='.txt', prefix='requirements')[1]
    req_str = ''
    if requirements:
        with open(requirements) as user_requirements:
            req_str = user_requirements.read()

    sdk_requirements_string = ''
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'requirements.txt'), 'r') as requirements:
        for line in requirements:
            if 'azureml-model-management-sdk' in line:
                sdk_requirements_string = line.strip()
                break

    with open(generated_requirements, 'w') as generated_requirements_file:
        generated_requirements_file.write('{}\n{}\n'.format(req_str.strip(), sdk_requirements_string))

    return generated_requirements


def get_auth_header():
    from ._az_util import az_login
    az_login()
    profile = Profile()
    cred, sub, tenant = profile.get_login_credentials()
    return cred.signed_session().headers['Authorization']


def query_mms_async_operation(operation_url, operation_headers, params, context):
    polling_iteration = 0
    while polling_iteration < MMS_ASYNC_OPERATION_POLLING_MAX_TRIES:
        try:
            operation_resp = context.http_call('get', operation_url, params=params, headers=operation_headers, timeout=MMS_SYNC_TIMEOUT_SECONDS)
            break
        except requests.ConnectionError:
            raise MlCliError('Error connecting to {}.'.format(operation_url))
        except requests.Timeout:
            print('Operation request timed out, trying again')
            polling_iteration += 1
            time.sleep(MMS_ASYNC_OPERATION_POLLING_INTERVAL_SECONDS)

    if polling_iteration == MMS_ASYNC_OPERATION_POLLING_MAX_TRIES:
        raise MlCliError('Error, operation request to {} timed out.'.format(operation_url))

    if operation_resp.status_code == 200:
        return get_json(operation_resp.content, pascal=True), operation_resp.headers
    else:
        raise MlCliError('Error occurred while polling for operation at {}.'.format(operation_url), operation_resp.headers, operation_resp.content, operation_resp.status_code)


def poll_mms_async_operation(operation_url, operation_headers, params, polling_max_tries, context):
    resp_obj, headers_obj = query_mms_async_operation(operation_url, operation_headers, params, context)

    polling_iteration = 0
    while 'State' in resp_obj and polling_iteration < polling_max_tries:
        operation_state = resp_obj['State']

        if operation_state == 'NotStarted' or operation_state == 'Running':
            time.sleep(MMS_ASYNC_OPERATION_POLLING_INTERVAL_SECONDS)
            sys.stdout.write('.')
            sys.stdout.flush()
            polling_iteration += 1
        elif operation_state == 'Succeeded':
            try:
                resource_id = resp_obj['ResourceLocation'].split('/')[-1]
            except KeyError:
                raise MlCliError('Invalid response key: ResourceLocation')
            return resource_id
        else:
            sys.stdout.write('Failed\n')
            sys.stdout.flush()
            return resp_obj, headers_obj

        resp_obj, headers_obj = query_mms_async_operation(operation_url, operation_headers, params, context)

    if polling_iteration == polling_max_tries:
        raise MlCliError('Error, operation polling timed out')
    else:
        raise MlCliError('Error, "State" not found in operation response: {}'.format(resp_obj))


def get_paginated_results(resp, headers, context):
    result = get_json(resp.content, pascal=True)
    try:
        items = result['Value']
    except ValueError:
        raise MlCliError('Error, unable to get key \'Value\' from paginated response: {}'.format(result))
    while 'NextLink' in result.keys():
        next_link = result['NextLink']
        polling_iteration = 0
        while polling_iteration < MMS_PAGINATED_RESPONSE_MAX_TRIES:
            try:
                resp = context.http_call('get', next_link, headers=headers, timeout=MMS_SYNC_TIMEOUT_SECONDS)
                break
            except requests.ConnectionError:
                raise MlCliError('Error connecting to {}.'.format(next_link))
            except requests.Timeout:
                print('Request timed out, trying again')
                polling_iteration += 1
                time.sleep(MMS_ASYNC_OPERATION_POLLING_INTERVAL_SECONDS)

        if polling_iteration == MMS_PAGINATED_RESPONSE_MAX_TRIES:
            raise MlCliError('Error, request to {} timed out.'.format(next_link))

        result = get_json(resp.content, pascal=True)
        try:
            items = items + result['Value']
        except ValueError:
            raise MlCliError('Error, unable to get key \'Value\' from paginated response: {}'.format(result))

    return items


def str_to_bool(str):
    try:
        str = str.lower()
        if str == 'true':
            return True
        elif str == 'false':
            return False
        else:
            return None
    except AttributeError as ae:
        logger.debug("str_to_bool({}) caught exception: {}".format(str, ae))
        return None


def conditional_update_or_remove(dictionary, tup, value):
    trav = dictionary
    for key in tup[:-1]:
        trav = trav[key]
    if value:
        trav[tup[-1]] = value
    else:
        del trav[tup[-1]]


def try_get_local_service(workspace, name, raise_exception=False):
    """Check whether a local service exists

    This is for CLI layer to check whether same name local service exists in the workspace
    so it can handle the logic (e.g. name conflict in creation) accordingly

    :param workspace: The current AzureML Workspace object
    :type workspace: azureml.core.workspace.Workspace
    :param name: The service name to look up
    :type name: string
    :param name: Whether to propagate the exception to called
    :type name: bool
    :return: Service object, or None if no such exception exists
    :rtype: azureml.core.webservice.LocalWebservice
    """
    try:
        # Note: Because there are many scenarios in which Exception (or even WebserviceException)
        # is thrown but we don't know whether service exists or not. e.g. cannot get local docker
        # client, cannot get docker host container etc., we pass the must_exist param as True and
        # explicitly check exception type (== WebserviceException) and message (contains WebserviceNotFound)
        # to detect the scenario same name local service doesn't exist.
        service = LocalWebservice(workspace, name, must_exist=True)
        return service
    except Exception as e:
        if isinstance(e, WebserviceException) and 'WebserviceNotFound' in e.message:
            # Same name local service doesn't exist
            return None
        else:
            # This is the case we hit exception which is not because of nonexisted local service
            # Handle the exception as per the raise_exception parameter
            if raise_exception:
                raise e
            else:
                # don't propage the exception to caller. instead, just log warning and return None
                logger.warning("Failed to check LocalWebservice existence: {}".format(e))
                return None

def get_file_content(file_name):
    if not file_name:
        return None

    try:
        with open(file_name, 'r') as f:
            return f.read()
    except (IOError, OSError) as exc:
        raise MlCliError("Error while reading ssl cert information from : {}".format(file_name))
