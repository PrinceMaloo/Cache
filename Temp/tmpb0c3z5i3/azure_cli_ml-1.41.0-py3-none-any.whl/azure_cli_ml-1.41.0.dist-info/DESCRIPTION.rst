Azure ML CLI extension for Azure CLI.



